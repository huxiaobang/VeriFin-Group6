# VeriFin research report

**Status:** partial
**Stop reason:** unresolved_items
**Request:** What if we take out sales from the refinery to outside customers? Show me how that changes the comparison.
**Request ID:** new-airline-2
**Model mode:** configured_model
**Scope version:** 5

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-04-09T23:59:59-04:00",
  "requirements": [
    {
      "id": "request:episode_04dccb16852d4d10b634ec29fcee92ba",
      "text": "Compare Delta's revenue for the three months ended March 31, 2025 and March 31, 2024 before and after excluding third-party refinery sales in both periods. Show the excluded amounts, adjusted revenue totals, and resulting year-over-year dollar and percentage growth, distinguishing the non-GAAP adjusted measure from reported revenue."
    }
  ]
}
```

## Findings

Research skills: attribute-portfolio-growth

### claim:reported-revenue-comparison — Supported

For Delta's fiscal 2025 Q1 versus fiscal 2024 Q1—the three months ended March 31, 2025 and March 31, 2024—reported consolidated operating revenue was USD 14,040 million versus USD 13,748 million. The income statement reports an increase of USD 292 million, or 2% rounded.

Evidence: chunk_61b1b30903786ec2dc3eb4a3, chunk_fa64016d0cc136960370cbb8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The consolidated income statement's Total operating revenue row gives USD 14,040 million for the three months ended March 31, 2025 and USD 13,748 million for the comparable 2024 period, with a disclosed USD 292 million increase and rounded 2% growth. The reconciliation explicitly labels the comparison 1Q25 versus 1Q24. These original rows establish the stated consolidated metric, periods and units.
chunk_61b1b30903786ec2dc3eb4a3 chunk_fa64016d0cc136960370cbb8

### claim:refinery-exclusions — Supported

Exclude third-party refinery sales of USD 1,062 million from March-quarter 2025 revenue and USD 1,185 million from March-quarter 2024 revenue. These are sales to outside customers, not a removal of all refinery-related activity.

Evidence: chunk_fa64016d0cc136960370cbb8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The reconciliation subtracts Third-party refinery sales of USD 1,062 million in March-quarter 2025 and USD 1,185 million in March-quarter 2024. The row explicitly limits the exclusion to third-party sales, supporting the distinction from removing all refinery-related activity.
chunk_fa64016d0cc136960370cbb8

### claim:adjusted-revenue-comparison — Supported

After those exclusions, Delta reports non-GAAP adjusted operating revenue of USD 12,978 million for fiscal 2025 Q1 versus USD 12,563 million for fiscal 2024 Q1. Its disclosed adjusted growth rate is 3.3%, rounded, compared with the reported revenue growth rate of 2%, rounded. Revenue therefore grew on both bases, with stronger percentage growth after excluding third-party refinery sales.

Evidence: chunk_fa64016d0cc136960370cbb8, chunk_61b1b30903786ec2dc3eb4a3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The reconciliation reports adjusted operating revenue of USD 12,978 million and USD 12,563 million in the March 2025 and March 2024 columns, respectively, with disclosed 3.3% growth. The income statement discloses rounded reported growth of 2%, and the release identifies adjusted revenue as non-GAAP. Both comparisons are positive, and adjusted percentage growth is higher. The intervening June 2024 column is correctly excluded.
chunk_fa64016d0cc136960370cbb8 chunk_61b1b30903786ec2dc3eb4a3 span_8e42ee228427c70bc97717f9

### claim:refinery-sales-decline — Supported

Third-party refinery sales declined by USD 123 million year over year, as disclosed in Delta's Other Revenue table. Including that declining revenue stream dampened reported dollar growth relative to growth excluding it.

Evidence: chunk_45576f8098291a7f8ab71e84, chunk_fa64016d0cc136960370cbb8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Other Revenue table explicitly reports refinery revenue of USD 1,062 million versus USD 1,185 million and a USD 123 million decline. The reconciliation identifies these same amounts as third-party refinery sales. Their negative year-over-year change arithmetically reduces reported dollar growth relative to growth excluding them; this is an accounting reconciliation, not an unsupported operational causal attribution.
chunk_45576f8098291a7f8ab71e84 chunk_fa64016d0cc136960370cbb8

### claim:calculation-limitation — Partially Supported

The adjusted dollar-growth calculation is USD 12,978 million minus USD 12,563 million.

Evidence: chunk_fa64016d0cc136960370cbb8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The formula uses the correct adjusted revenue amounts and comparable March-quarter columns. No saved calculation record is supplied, and 3.3% is indeed issuer-disclosed. However, the conclusion that the dollar increase must remain unverified is not justified: direct subtraction of the original table amounts establishes USD 415 million without a saved tool record.
chunk_fa64016d0cc136960370cbb8

## Answers to your questions

**What if we take out sales from the refinery to outside customers?**

answered — After those exclusions, Delta reports non-GAAP adjusted operating revenue of USD 12,978 million for fiscal 2025 Q1 versus USD 12,563 million for fiscal 2024 Q1. Its disclosed adjusted growth rate is 3.3%, rounded, compared with the reported revenue growth rate of 2%, rounded. Revenue therefore grew on both bases, with stronger percentage growth after excluding third-party refinery sales. Exclude third-party refinery sales of USD 1,062 million from March-quarter 2025 revenue and USD 1,185 million from March-quarter 2024 revenue. These are sales to outside customers, not a removal of all refinery-related activity. [claim:adjusted-revenue-comparison, claim:refinery-exclusions]

**Show me how that changes the comparison.**

partial — After those exclusions, Delta reports non-GAAP adjusted operating revenue of USD 12,978 million for fiscal 2025 Q1 versus USD 12,563 million for fiscal 2024 Q1. Its disclosed adjusted growth rate is 3.3%, rounded, compared with the reported revenue growth rate of 2%, rounded. Revenue therefore grew on both bases, with stronger percentage growth after excluding third-party refinery sales. For Delta's fiscal 2025 Q1 versus fiscal 2024 Q1—the three months ended March 31, 2025 and March 31, 2024—reported consolidated operating revenue was USD 14,040 million versus USD 13,748 million. The income statement reports an increase of USD 292 million, or 2% rounded. Exclude third-party refinery sales of USD 1,062 million from March-quarter 2025 revenue and USD 1,185 million from March-quarter 2024 revenue. These are sales to outside customers, not a removal of all refinery-related activity. Third-party refinery sales declined by USD 123 million year over year, as disclosed in Delta's Other Revenue table. Including that declining revenue stream dampened reported dollar growth relative to growth excluding it. The draft does not state the adjusted dollar increase of USD 415 million or explicitly compare it with the reported USD 292 million increase, despite the original table supplying all necessary amounts. [claim:adjusted-revenue-comparison, claim:reported-revenue-comparison, claim:refinery-exclusions, claim:refinery-sales-decline]

## Unanswered items and issues

- request:episode_04dccb16852d4d10b634ec29fcee92ba: Compare Delta's revenue for the three months ended March 31, 2025 and March 31, 2024 before and after excluding third-party refinery sales in both periods. Show the excluded amounts, adjusted revenue totals, and resulting year-over-year dollar and percentage growth, distinguishing the non-GAAP adjusted measure from reported revenue.
- claim:calculation-limitation: unsupported_statement. The absence of a saved calculation record does not make the adjusted dollar increase unverifiable. The original reconciliation supplies comparable amounts of USD 12,978 million and USD 12,563 million, whose difference is USD 415 million. Suggested action: Replace the asserted verification limitation with transparent subtraction showing an adjusted revenue increase of USD 415 million. Continue to identify 3.3% as the issuer-disclosed rounded growth rate, without claiming a tool-generated calculation.
- request:episode_04dccb16852d4d10b634ec29fcee92ba: omission. The draft omits the requested adjusted year-over-year dollar increase and therefore does not fully quantify how excluding third-party refinery sales changes the comparison. It provides the operands but withholds their USD 415 million difference. Suggested action: State that adjusted revenue increased by USD 415 million, compared with the reported increase of USD 292 million. Explain that the USD 123 million decline in third-party refinery sales reconciles these increases: USD 415 million minus USD 123 million equals USD 292 million. Retain the separately labeled issuer-disclosed rounded growth rates of 3.3% and 2%.
- part-2: omission. Show me how that changes the comparison. — The draft does not state the adjusted dollar increase of USD 415 million or explicitly compare it with the reported USD 292 million increase, despite the original table supplying all necessary amounts. Suggested action: 对照用户原问，补出有出处的回答；现有资料不足时保留具体缺口。

## Evidence and source locations

- **metadata_865d90943eca5128a0016a6c** (DAL;  to ): manifest.json
  Locator: documents[3]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_8e42ee228427c70bc97717f9** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_fa64016d0cc136960370cbb8** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[29991:31098] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_91babab9d93af45918cd67e1** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[32130:33924] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_e182ab901ab9d0edfe0db2b0** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[34982:36523] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_45576f8098291a7f8ab71e84** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[22830:24320] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_0c8220f41445ed0b11285e78** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[33681:35232] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_61b1b30903786ec2dc3eb4a3** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[20069:21863] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **span_346ffbbcb0d32868b2ad32df**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[29991:31098] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 1; active seconds: 64.51.
Token usage (when returned by provider): {"planner_steps": 2, "total_tokens": 67898, "total_tokens_reported_calls": 4, "prompt_tokens": 63768, "prompt_tokens_reported_calls": 4, "completion_tokens": 4130, "completion_tokens_reported_calls": 4, "cached_input_tokens": 39698, "cached_input_tokens_reported_calls": 4, "cache_write_tokens": 5675, "cache_write_tokens_reported_calls": 4, "cache_write_30m_tokens": 5675, "cache_write_30m_tokens_reported_calls": 4, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 4, "reasoning_tokens": 412, "reasoning_tokens_reported_calls": 4}
