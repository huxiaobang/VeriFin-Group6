# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Did Disney’s streaming business actually make money in fiscal Q2 2025? Show me the figure and where you got it.
**Request ID:** new-disney-1
**Model mode:** configured_model
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-05-07",
  "requirements": [
    {
      "id": "R1",
      "text": "Determine whether Disney's streaming business was profitable in fiscal Q2 2025, identifying the reported profit measure and business scope."
    },
    {
      "id": "R2",
      "text": "Provide the reported figure and cite an original Disney disclosure available by May 7, 2025, confirming the fiscal period."
    }
  ]
}
```

## Findings

### claim:dis-streaming-q2-2025-profit — Supported

Yes—Disney’s Entertainment Direct-to-Consumer business (Disney+ and Hulu) reported US$336 million in operating income in fiscal Q2 2025, ended March 29, 2025. This establishes operating profitability, not net income or cash flow.

Evidence: chunk_2d8c5936a0b1f8623f80eda8, chunk_d37290571b5c2a2fed0998d0, span_c32bb7cef0175f6e8e0729b3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Entertainment segment table identifies Direct-to-Consumer operating income of $336 million in the quarter ended March 29, 2025. The detailed DTC passage repeats that amount and identifies Disney+ and Hulu as its DTC product offerings. The release opening confirms fiscal Q2 2025. A positive reported operating-income amount supports operating profitability, without establishing net income or cash flow.
chunk_2d8c5936a0b1f8623f80eda8 chunk_d37290571b5c2a2fed0998d0 span_c32bb7cef0175f6e8e0729b3

### claim:dis-streaming-figure-source — Supported

The figure is US$336 million of operating income for fiscal Q2 2025, from the Direct-to-Consumer table on page 5 of Disney’s May 7, 2025 earnings release. The original table, stated in millions of dollars, reads “Operating income $ 336 $ 47 &gt;100 %” for the quarters ended March 29, 2025 and March 30, 2024, respectively. Source: https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf ; saved passage characters [9777:11617).

Evidence: chunk_2d8c5936a0b1f8623f80eda8, span_c32bb7cef0175f6e8e0729b3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The original Direct-to-Consumer table labels amounts in millions and reports operating income of $336 million and $47 million under March 29, 2025 and March 30, 2024, respectively. The passage includes the printed page-5 boundary. The release is dated May 7, 2025, and its source URL and saved passage offsets match the claim.
chunk_2d8c5936a0b1f8623f80eda8 span_c32bb7cef0175f6e8e0729b3

### claim:dis-streaming-prior-year-profit — Supported

The same table reports US$47 million in operating income for Entertainment Direct-to-Consumer in fiscal Q2 2024, the quarter ended March 30, 2024.

Evidence: chunk_2d8c5936a0b1f8623f80eda8, span_c32bb7cef0175f6e8e0729b3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The DTC operating-income row places $47 million in the March 30, 2024 quarterly column. The Entertainment table independently confirms the business scope, and the release identifies the comparative quarter as fiscal Q2 2024.
chunk_2d8c5936a0b1f8623f80eda8 chunk_d37290571b5c2a2fed0998d0 span_c32bb7cef0175f6e8e0729b3

### claim:dis-release-fiscal-period — Supported

Disney’s May 7, 2025 release identifies fiscal Q2 2025 explicitly: its heading reads “SECOND QUARTER AND SIX MONTHS EARNINGS FOR FISCAL 2025,” and its opening states “second fiscal quarter ended March 29, 2025.” Locator: page 1, saved release passage characters [0:6000).

Evidence: span_c32bb7cef0175f6e8e0729b3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The first page is dated May 7, 2025, contains the quoted fiscal-2025 second-quarter heading, and explicitly identifies the second fiscal quarter ended March 29, 2025. Both quotations and the page and offset locator match the original passage.
span_c32bb7cef0175f6e8e0729b3

## Answers to your questions

**Did Disney’s streaming business actually make money in fiscal Q2 2025?**

answered — Yes—Disney’s Entertainment Direct-to-Consumer business (Disney+ and Hulu) reported US$336 million in operating income in fiscal Q2 2025, ended March 29, 2025. [claim:dis-streaming-q2-2025-profit]

**Show me the figure and where you got it.**

answered — The figure is US$336 million of operating income for fiscal Q2 2025, from the Direct-to-Consumer table on page 5 of Disney’s May 7, 2025 earnings release. The original table, stated in millions of dollars, reads “Operating income $ 336 $ 47 &gt;100 %” for the quarters ended March 29, 2025 and March 30, 2024, respectively. Source: https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf ; saved passage characters [9777:11617). Disney’s May 7, 2025 release identifies fiscal Q2 2025 explicitly: its heading reads “SECOND QUARTER AND SIX MONTHS EARNINGS FOR FISCAL 2025,” and its opening states “second fiscal quarter ended March 29, 2025.” Locator: page 1, saved release passage characters [0:6000). [claim:dis-streaming-figure-source, claim:dis-release-fiscal-period]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_87258ad4804e70335dd6bd5e**（本轮留存） (DIS;  to ): manifest.json
  Locator: documents[2]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_c32bb7cef0175f6e8e0729b3**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_2d8c5936a0b1f8623f80eda8**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[9777:11617] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_7a8a6ab350f15d909d44995d**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:1798] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_d37290571b5c2a2fed0998d0**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[7750:8883] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_62b86eb163756c5431c9438b**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[6894:8016] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf

## Reproducible calculations


## Resource use

Model attempts: 13; tool attempts: 3; active seconds: 136.04.
Token usage (when returned by provider): {"planner_steps": 7, "total_tokens": 163104, "total_tokens_reported_calls": 13, "prompt_tokens": 155707, "prompt_tokens_reported_calls": 13, "completion_tokens": 7397, "completion_tokens_reported_calls": 13, "cached_input_tokens": 66920, "cached_input_tokens_reported_calls": 13, "cache_write_tokens": 7352, "cache_write_tokens_reported_calls": 13, "cache_write_30m_tokens": 7352, "cache_write_30m_tokens_reported_calls": 13, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 13, "reasoning_tokens": 381, "reasoning_tokens_reported_calls": 13}
