# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Wait, was that the whole Entertainment segment? How much did each earn, and how did each compare with a year earlier?
**Request ID:** new-disney-2
**Model mode:** configured_model
**Scope version:** 5

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-05-07",
  "requirements": [
    {
      "id": "request:episode_12a7b3f9f44d46f895eded88ebff6363",
      "text": "Wait, was that the whole Entertainment segment? How much did each earn, and how did each compare with a year earlier?"
    },
    {
      "id": "R-scope-comparison",
      "text": "Distinguish Entertainment Direct-to-Consumer from the whole Entertainment segment; provide each business's reported operating income for fiscal Q2 2025 and fiscal Q2 2024 and its reported year-over-year change, citing Disney's original disclosure available by May 7, 2025."
    }
  ]
}
```

## Findings

### claim:dis-dtc-scope-clarification — Supported

No—the US$336 million was operating income for Entertainment Direct-to-Consumer (Disney+ and Hulu), a business within Entertainment, not the whole Entertainment segment. It is an operating-profit measure, not net income.

Evidence: chunk_d37290571b5c2a2fed0998d0, chunk_2d8c5936a0b1f8623f80eda8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Entertainment table lists Direct-to-Consumer as a constituent business and places US$336 million in its quarterly operating-income row, rather than the segment total. The detailed DTC passage identifies Disney+ and Hulu as its product offerings. The row is explicitly operating income, not net income.
chunk_d37290571b5c2a2fed0998d0 chunk_2d8c5936a0b1f8623f80eda8

### claim:dis-dtc-reported-comparison — Supported

Entertainment Direct-to-Consumer earned US$336 million in operating income in fiscal Q2 2025, versus US$47 million in fiscal Q2 2024. Disney reported the year-over-year increase as greater than 100%. Source: the Direct-to-Consumer table, page 5 of Disney’s May 7, 2025 earnings release.

Evidence: chunk_2d8c5936a0b1f8623f80eda8, chunk_d37290571b5c2a2fed0998d0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The original DTC table, stated in millions of dollars, reports quarterly operating income of US$336 million for March 29, 2025 and US$47 million for March 30, 2024, with the change printed as &gt;100%. The page-5 boundary and May 7, 2025 release date support the source description. This is the issuer's reported change, not a claimed independently calculated growth rate.
chunk_2d8c5936a0b1f8623f80eda8 chunk_d37290571b5c2a2fed0998d0 span_c32bb7cef0175f6e8e0729b3

### claim:dis-entertainment-reported-comparison — Supported

The whole Entertainment segment earned US$1,258 million in operating income in fiscal Q2 2025, versus US$781 million in fiscal Q2 2024—a reported year-over-year increase of 61%. Source: the Entertainment segment table on page 4 of Disney’s May 7, 2025 earnings release, saved passage characters [7750:8883): https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf.

Evidence: chunk_d37290571b5c2a2fed0998d0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Entertainment operating-income total in the quarterly columns is US$1,258 million for March 29, 2025 versus US$781 million for March 30, 2024, with reported growth of 61%. These are not the adjacent six-month totals. The passage contains the page-4 boundary, and its inherited publication date and source URL match the citation.
chunk_d37290571b5c2a2fed0998d0

### claim:dis-comparison-fiscal-periods — Supported

These are quarterly figures, not six-month totals: Disney’s release identifies fiscal Q2 2025 as the “second fiscal quarter ended March 29, 2025” (page 1, saved passage characters [0:6000)). The Entertainment table compares that quarter with fiscal Q2 2024, ended March 30, 2024.

Evidence: span_c32bb7cef0175f6e8e0729b3, chunk_d37290571b5c2a2fed0998d0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release opening explicitly identifies the second fiscal quarter ended March 29, 2025. The Entertainment table separately labels quarterly and six-month columns and compares the quarterly figures with March 30, 2024. The release's summarized results identify that comparative quarter as fiscal Q2 2024.
span_c32bb7cef0175f6e8e0729b3 chunk_d37290571b5c2a2fed0998d0

### claim:dis-star-india-comparability — Supported

Comparability caveat: Star India was consolidated only through November 14, 2024; after the joint-venture transaction, Disney began recognizing its 37% share of the venture’s results in “Equity in the income of investees.” Thus, the reported year-over-year comparisons include a scope change and should not be treated as constant-scope growth.

Evidence: chunk_62b86eb163756c5431c9438b, chunk_d37290571b5c2a2fed0998d0, chunk_2d8c5936a0b1f8623f80eda8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The transaction passage dates completion to November 14, 2024. The following original passage states that Star India was consolidated through that date and that Disney subsequently recognized its 37% share in equity income. The DTC discussion explicitly identifies the absence of Star India subscription revenue and programming costs in the current quarter. These disclosures support the scope-change caveat without establishing or claiming a quantified constant-scope comparison.
chunk_62b86eb163756c5431c9438b chunk_d37290571b5c2a2fed0998d0 chunk_2d8c5936a0b1f8623f80eda8

## Answers to your questions

**Wait, was that the whole Entertainment segment?**

answered — No—the US$336 million was operating income for Entertainment Direct-to-Consumer (Disney+ and Hulu), a business within Entertainment, not the whole Entertainment segment. [claim:dis-dtc-scope-clarification]

**How much did each earn, and how did each compare with a year earlier?**

answered — The whole Entertainment segment earned US$1,258 million in operating income in fiscal Q2 2025, versus US$781 million in fiscal Q2 2024—a reported year-over-year increase of 61%. Source: the Entertainment segment table on page 4 of Disney’s May 7, 2025 earnings release, saved passage characters [7750:8883): https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf. Entertainment Direct-to-Consumer earned US$336 million in operating income in fiscal Q2 2025, versus US$47 million in fiscal Q2 2024. Disney reported the year-over-year increase as greater than 100%. Source: the Direct-to-Consumer table, page 5 of Disney’s May 7, 2025 earnings release. These are quarterly figures, not six-month totals: Disney’s release identifies fiscal Q2 2025 as the “second fiscal quarter ended March 29, 2025” (page 1, saved passage characters [0:6000)). The Entertainment table compares that quarter with fiscal Q2 2024, ended March 30, 2024. Comparability caveat: Star India was consolidated only through November 14, 2024; after the joint-venture transaction, Disney began recognizing its 37% share of the venture’s results in “Equity in the income of investees.” Thus, the reported year-over-year comparisons include a scope change and should not be treated as constant-scope growth. [claim:dis-entertainment-reported-comparison, claim:dis-dtc-reported-comparison, claim:dis-comparison-fiscal-periods, claim:dis-star-india-comparability]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_87258ad4804e70335dd6bd5e** (DIS;  to ): manifest.json
  Locator: documents[2]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_c32bb7cef0175f6e8e0729b3** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_2d8c5936a0b1f8623f80eda8** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[9777:11617] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_7a8a6ab350f15d909d44995d** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:1798] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_d37290571b5c2a2fed0998d0** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[7750:8883] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_62b86eb163756c5431c9438b** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[6894:8016] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 0; active seconds: 53.55.
Token usage (when returned by provider): {"planner_steps": 2, "total_tokens": 58952, "total_tokens_reported_calls": 4, "prompt_tokens": 55758, "prompt_tokens_reported_calls": 4, "completion_tokens": 3194, "completion_tokens_reported_calls": 4, "cached_input_tokens": 33656, "cached_input_tokens_reported_calls": 4, "cache_write_tokens": 3226, "cache_write_tokens_reported_calls": 4, "cache_write_30m_tokens": 3226, "cache_write_30m_tokens_reported_calls": 4, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 4, "reasoning_tokens": 201, "reasoning_tokens_reported_calls": 4}
