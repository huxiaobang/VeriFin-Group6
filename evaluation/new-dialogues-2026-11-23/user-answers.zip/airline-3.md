# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Then did each available seat mile earn more on that same basis, or was there just more capacity? Point me to the figures.
**Request ID:** new-airline-3
**Model mode:** configured_model
**Scope version:** 7

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-04-09T23:59:59-04:00",
  "requirements": [
    {
      "id": "request:episode_83447eaaad5242c28fba18e592db7d22",
      "text": "Compare Delta's March-quarter 2025 and March-quarter 2024 revenue per available seat mile excluding third-party refinery sales, alongside available seat miles and adjusted revenue growth. State whether unit revenue increased or whether capacity expanded despite lower unit revenue, distinguish revenue from profit, and cite the original reconciliation and statistical figures."
    }
  ],
  "entities": [
    "DAL"
  ]
}
```

## Findings

Research skills: reconcile-per-unit-financials

### claim:adjusted-unit-revenue — Supported

No—each available seat mile generated less revenue on the same refinery-excluded basis. For Delta's fiscal 2025 Q1 versus fiscal 2024 Q1, adjusted total revenue per available seat mile (TRASM) was 18.97 US cents versus 19.17 US cents, down 1.0% as disclosed. This non-GAAP measure excludes third-party refinery sales. See the release's page 12 adjusted TRASM reconciliation.

Evidence: chunk_fa64016d0cc136960370cbb8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The page 12 reconciliation explicitly reports adjusted TRASM of 18.97 cents for March-quarter 2025 versus 19.17 cents for March-quarter 2024 and a disclosed decline of 1.0%. The adjustment removes third-party refinery sales. The claim correctly selects the March comparative periods and identifies the rate as disclosed rather than independently calculated.
chunk_fa64016d0cc136960370cbb8

### claim:capacity-expanded — Supported

Capacity expanded: available seat miles were 68,401 million in the three months ended March 31, 2025, versus 65,542 million a year earlier, up 4% as disclosed. These are the capacity denominators for the unit-revenue comparison. See the release's Statistical Summary on page 9, which also repeats the adjusted TRASM figures.

Evidence: chunk_45576f8098291a7f8ab71e84
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The page 9 Statistical Summary reports 68,401 million available seat miles for the three months ended March 31, 2025 versus 65,542 million for 2024, with a disclosed 4% increase. It also repeats adjusted TRASM. Dividing the corresponding adjusted revenue amounts by these capacity figures and converting USD to cents reproduces the disclosed unit revenues at their displayed precision, supporting the denominator identification.
chunk_45576f8098291a7f8ab71e84 chunk_fa64016d0cc136960370cbb8

### claim:adjusted-revenue-capacity-interpretation — Supported

Adjusted operating revenue nevertheless rose 3.3% as disclosed, to USD 12,978 million from USD 12,563 million. Thus, the revenue increase accompanied more capacity despite lower revenue per available seat mile—not higher unit revenue. This is an arithmetic interpretation of revenue, capacity and their ratio, not a claim about the underlying business causes.

Evidence: chunk_fa64016d0cc136960370cbb8, chunk_45576f8098291a7f8ab71e84
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The reconciliation reports March-quarter adjusted operating revenue of USD 12,978 million in 2025 versus USD 12,563 million in 2024, with disclosed growth of 3.3%. The statistical figures establish increased capacity alongside lower adjusted unit revenue. The interpretation accurately describes this arithmetic relationship without asserting an underlying business cause.
chunk_fa64016d0cc136960370cbb8 chunk_45576f8098291a7f8ab71e84

### claim:unit-revenue-not-profit — Supported

Here, “per available seat mile” measures revenue divided by available seat miles, not profit per seat mile. Adjusted TRASM does not deduct operating costs, so these figures alone do not establish whether profit per unit increased.

Evidence: chunk_fa64016d0cc136960370cbb8
Calculations: 

The source names the metric Total Revenue Per Available Seat Mile and reconciles it by removing third-party refinery sales, not operating costs. It separately presents operating income. The claim correctly distinguishes revenue per unit from profit per unit and limits what the cited revenue figures establish.
chunk_fa64016d0cc136960370cbb8

## Answers to your questions

**Then did each available seat mile earn more on that same basis, or was there just more capacity?**

answered — Adjusted operating revenue nevertheless rose 3.3% as disclosed, to USD 12,978 million from USD 12,563 million. Thus, the revenue increase accompanied more capacity despite lower revenue per available seat mile—not higher unit revenue. This is an arithmetic interpretation of revenue, capacity and their ratio, not a claim about the underlying business causes. No—each available seat mile generated less revenue on the same refinery-excluded basis. For Delta's fiscal 2025 Q1 versus fiscal 2024 Q1, adjusted total revenue per available seat mile (TRASM) was 18.97 US cents versus 19.17 US cents, down 1.0% as disclosed. This non-GAAP measure excludes third-party refinery sales. See the release's page 12 adjusted TRASM reconciliation. Capacity expanded: available seat miles were 68,401 million in the three months ended March 31, 2025, versus 65,542 million a year earlier, up 4% as disclosed. These are the capacity denominators for the unit-revenue comparison. See the release's Statistical Summary on page 9, which also repeats the adjusted TRASM figures. Here, “per available seat mile” measures revenue divided by available seat miles, not profit per seat mile. Adjusted TRASM does not deduct operating costs, so these figures alone do not establish whether profit per unit increased. [claim:adjusted-revenue-capacity-interpretation, claim:adjusted-unit-revenue, claim:capacity-expanded, claim:unit-revenue-not-profit]

**Point me to the figures.**

answered — No—each available seat mile generated less revenue on the same refinery-excluded basis. For Delta's fiscal 2025 Q1 versus fiscal 2024 Q1, adjusted total revenue per available seat mile (TRASM) was 18.97 US cents versus 19.17 US cents, down 1.0% as disclosed. This non-GAAP measure excludes third-party refinery sales. See the release's page 12 adjusted TRASM reconciliation. [claim:adjusted-unit-revenue]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_865d90943eca5128a0016a6c** (DAL;  to ): manifest.json
  Locator: documents[3]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_8e42ee228427c70bc97717f9** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_fa64016d0cc136960370cbb8** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[29991:31098] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_91babab9d93af45918cd67e1** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[32130:33924] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_e182ab901ab9d0edfe0db2b0** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[34982:36523] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_45576f8098291a7f8ab71e84** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[22830:24320] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_0c8220f41445ed0b11285e78** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[33681:35232] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_61b1b30903786ec2dc3eb4a3** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[20069:21863] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **span_346ffbbcb0d32868b2ad32df** (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[29991:31098] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 0; active seconds: 53.68.
Token usage (when returned by provider): {"planner_steps": 2, "total_tokens": 82714, "total_tokens_reported_calls": 4, "prompt_tokens": 79963, "prompt_tokens_reported_calls": 4, "completion_tokens": 2751, "completion_tokens_reported_calls": 4, "cached_input_tokens": 54745, "cached_input_tokens_reported_calls": 4, "cache_write_tokens": 6929, "cache_write_tokens_reported_calls": 4, "cache_write_30m_tokens": 6929, "cache_write_30m_tokens_reported_calls": 4, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 4, "reasoning_tokens": 125, "reasoning_tokens_reported_calls": 4}
