# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Did Delta's revenue actually grow in the March 2025 quarter? How much did it bring in compared with a year earlier?
**Request ID:** new-airline-1
**Model mode:** configured_model
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-04-09T23:59:59-04:00",
  "requirements": [
    {
      "id": "r1",
      "text": "Establish whether Delta Air Lines' reported revenue grew in the March 2025 quarter versus the comparable prior-year quarter using disclosures available by April 9, 2025."
    },
    {
      "id": "r2",
      "text": "Report comparable quarterly revenue amounts in USD, the year-over-year dollar and percentage changes, and distinguish reported revenue from any adjusted revenue growth cited."
    }
  ]
}
```

## Findings

### claim:reported-revenue — Supported

Yes. Delta Air Lines' reported operating revenue grew in fiscal 2025 Q1. It brought in USD 14.040 billion for the three months ended March 31, 2025, compared with USD 13.748 billion for the three months ended March 31, 2024. Its April 9, 2025 release labels the comparison “1Q25 vs 1Q24.”

Evidence: chunk_61b1b30903786ec2dc3eb4a3, chunk_fa64016d0cc136960370cbb8, span_8e42ee228427c70bc97717f9
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The consolidated statements' Total operating revenue row reports USD 14,040 million and USD 13,748 million for the three months ended March 31, 2025 and 2024, respectively. Conversion to USD billions is correct and establishes growth. The reconciliation explicitly labels the comparison 1Q25 vs 1Q24. The release body identifies Delta and its April 9, 2025 publication date, within the cutoff, notwithstanding the misleading year in the URL filename.
chunk_61b1b30903786ec2dc3eb4a3 chunk_fa64016d0cc136960370cbb8 span_8e42ee228427c70bc97717f9

### claim:reported-revenue-increase — Supported

For fiscal 2025 Q1 versus fiscal 2024 Q1, Delta's consolidated income statement discloses a reported operating revenue increase of USD 292 million, or 2% rounded.

Evidence: chunk_61b1b30903786ec2dc3eb4a3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The consolidated statements' Total operating revenue row explicitly discloses a USD 292 million increase and 2% growth. Subtracting USD 13,748 million from USD 14,040 million confirms the dollar change. The percentage is appropriately identified as the issuer's rounded disclosure rather than a more precise derived rate.
chunk_61b1b30903786ec2dc3eb4a3

### claim:adjusted-revenue — Supported

The separate 3.3% growth figure refers to adjusted operating revenue, not reported revenue. Adjusted revenue was USD 12.978 billion in fiscal 2025 Q1 versus USD 12.563 billion in fiscal 2024 Q1, excluding third-party refinery sales in both periods.

Evidence: chunk_fa64016d0cc136960370cbb8
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The reconciliation reports adjusted operating revenue of USD 12,978 million for March 2025 and USD 12,563 million for March 2024, with 3.3% growth. It subtracts third-party refinery sales of USD 1,062 million and USD 1,185 million, respectively, from reported operating revenue. The claim correctly selects the March comparative columns rather than the intervening June 2024 column and distinguishes adjusted from reported growth.
chunk_fa64016d0cc136960370cbb8

## Answers to your questions

**Did Delta's revenue actually grow in the March 2025 quarter?**

answered — Yes. Delta Air Lines' reported operating revenue grew in fiscal 2025 Q1. It brought in USD 14.040 billion for the three months ended March 31, 2025, compared with USD 13.748 billion for the three months ended March 31, 2024. Its April 9, 2025 release labels the comparison “1Q25 vs 1Q24.” For fiscal 2025 Q1 versus fiscal 2024 Q1, Delta's consolidated income statement discloses a reported operating revenue increase of USD 292 million, or 2% rounded. The separate 3.3% growth figure refers to adjusted operating revenue, not reported revenue. Adjusted revenue was USD 12.978 billion in fiscal 2025 Q1 versus USD 12.563 billion in fiscal 2024 Q1, excluding third-party refinery sales in both periods. [claim:reported-revenue, claim:reported-revenue-increase, claim:adjusted-revenue]

**How much did it bring in compared with a year earlier?**

answered — Yes. Delta Air Lines' reported operating revenue grew in fiscal 2025 Q1. It brought in USD 14.040 billion for the three months ended March 31, 2025, compared with USD 13.748 billion for the three months ended March 31, 2024. Its April 9, 2025 release labels the comparison “1Q25 vs 1Q24.” [claim:reported-revenue]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_865d90943eca5128a0016a6c**（本轮留存） (DAL;  to ): manifest.json
  Locator: documents[3]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_8e42ee228427c70bc97717f9**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_fa64016d0cc136960370cbb8**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[29991:31098] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_91babab9d93af45918cd67e1**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[32130:33924] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_e182ab901ab9d0edfe0db2b0**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[34982:36523] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_45576f8098291a7f8ab71e84**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[22830:24320] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_0c8220f41445ed0b11285e78**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[33681:35232] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e
- **chunk_61b1b30903786ec2dc3eb4a3**（本轮留存） (DAL;  to ): [source](<https://s2.q4cdn.com/181345880/files/doc_earnings/2025/q1/earnings-result/Delta-Air-Lines-Announces-First-Quarter-2024.pdf>)
  Locator: snapshots/dal-q1-2025.pdf.text.txt:characters[20069:21863] (zero-based Unicode offsets); snapshot SHA-256: 0b4fc888cf051b8951e23500f1295c280328c70346b5b46405fbe33c0aa21e0e

## Reproducible calculations


## Resource use

Model attempts: 17; tool attempts: 4; active seconds: 186.36.
Token usage (when returned by provider): {"planner_steps": 9, "total_tokens": 257638, "total_tokens_reported_calls": 17, "prompt_tokens": 247615, "prompt_tokens_reported_calls": 17, "completion_tokens": 10023, "completion_tokens_reported_calls": 17, "cached_input_tokens": 116159, "cached_input_tokens_reported_calls": 17, "cache_write_tokens": 10049, "cache_write_tokens_reported_calls": 17, "cache_write_30m_tokens": 10049, "cache_write_30m_tokens_reported_calls": 17, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 17, "reasoning_tokens": 1196, "reasoning_tokens_reported_calls": 17}
