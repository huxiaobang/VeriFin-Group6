# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** So can I say that many different households were paying? What exactly does the company count?
**Request ID:** new-disney-4
**Model mode:** configured_model
**Scope version:** 9

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-05-07",
  "requirements": [
    {
      "id": "request:episode_68e1c26b9651406aa83ed49076861f4e",
      "text": "Explain whether the fiscal Q2 2025 combined Disney+ and Hulu subscription total represents distinct paying households, and describe Disney's disclosed paid-subscriber counting rules, including bundles, wholesale entitlements, extra-member add-ons and when subscribers cease to count; cite the original disclosure available by May 7, 2025."
    }
  ]
}
```

## Findings

### claim:dis-household-count-limitation — Supported

No—you cannot describe Disney’s reported 180.7 million Disney+ and Hulu subscriptions at fiscal Q2 2025 quarter-end as 180.7 million different paying households. The total is not deduplicated across services: Disney counts subscribers to multi-product offerings separately for each included service. The cited disclosure does not establish the number of distinct paying households.

Evidence: span_c32bb7cef0175f6e8e0729b3, chunk_d176ca5b9e7c9bcabcfa359a
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release explicitly reports 180.7 million Disney+ and Hulu subscriptions for fiscal Q2 2025. The original paid-subscriber definition counts U.S. multi-product subscribers for each included service, establishing that the combined total is not deduplicated across services and cannot establish distinct paying households.
span_c32bb7cef0175f6e8e0729b3 chunk_d176ca5b9e7c9bcabcfa359a

### claim:dis-paid-subscriber-revenue-definition — Supported

Disney defines paid subscribers as subscribers “for which we recognized subscription revenue.” This is the company’s revenue-based subscriber definition, not a count of individual viewers or households. Source: “Paid subscribers,” page 16 of Disney’s May 7, 2025 earnings release.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The original “Paid subscribers” passage states that paid subscribers reflect subscribers “for which we recognized subscription revenue.” Its service-level bundle rules and extra-member exclusion support distinguishing this metric from individual viewers or households. The passage follows the printed page-15 boundary and belongs to page 16 of the May 7, 2025 release.
chunk_d176ca5b9e7c9bcabcfa359a

### claim:dis-bundle-counting-rules — Supported

For U.S. multi-product offerings, a subscriber counts as a paid subscriber for each included Disney service. Specifically, a Hulu Live TV + SVOD subscriber counts once for Hulu Live TV + SVOD, once for Disney+, and once for ESPN+. Consequently, that bundle contributes to both the Disney+ and Hulu counts; ESPN+ is separate from the combined Disney+ and Hulu total.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a, span_c32bb7cef0175f6e8e0729b3
Calculations: 

The original definition expressly counts U.S. multi-product subscribers for each included company service and specifies one count each for Hulu Live TV + SVOD, Disney+ and ESPN+. The release labels the 180.7 million total as Disney+ and Hulu subscriptions, so the example contributes to both included services while ESPN+ is outside that combined total.
chunk_d176ca5b9e7c9bcabcfa359a span_c32bb7cef0175f6e8e0729b3

### claim:dis-wholesale-entitlements — Supported

Disney includes subscribers entitled to a service through wholesale arrangements, including arrangements in which the service is available to each subscriber of an existing content-distribution tier. Thus, the count is not restricted to customers buying a standalone subscription directly from Disney.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a
Calculations: 

The original definition includes subscribers receiving a service entitlement through wholesale arrangements, including availability to each subscriber of an existing content-distribution tier. This directly supports the conclusion that the metric is not limited to standalone purchases made directly from Disney.
chunk_d176ca5b9e7c9bcabcfa359a

### claim:dis-extra-member-exclusion — Supported

Extra members added to an account through an extra-member add-on are not counted as paid subscribers.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a
Calculations: 

The original paid-subscriber passage describes extra-member add-ons and explicitly states, “These extra members are not counted as paid subscribers.”
chunk_d176ca5b9e7c9bcabcfa359a

### claim:dis-subscriber-cessation — Supported

Subscribers cease to count as paid subscribers as of their effective cancellation date or as a result of a failed payment method.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a
Calculations: 

The original definition states that subscribers cease to be paid subscribers as of their effective cancellation date or as a result of a failed payment method, matching both cessation conditions without adding an unsupported timing assumption.
chunk_d176ca5b9e7c9bcabcfa359a

### claim:dis-counting-source-period — Supported

These definitions appear on page 16, under “DTC PRODUCT DESCRIPTIONS AND KEY DEFINITIONS,” in Disney’s May 7, 2025 earnings release (saved passage characters [26551:28318)). The release identifies fiscal Q2 2025 as the “second fiscal quarter ended March 29, 2025” on page 1 (saved passage characters [0:6000)). Original source: https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a, span_c32bb7cef0175f6e8e0729b3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The definitions passage at offsets [26551:28318) contains the named heading after the printed page-15 boundary. The opening passage at [0:6000) is dated May 7, 2025 and explicitly identifies the second fiscal quarter ended March 29, 2025. The inherited original source URL matches the cited PDF and the publication meets the cutoff.
chunk_d176ca5b9e7c9bcabcfa359a span_c32bb7cef0175f6e8e0729b3

## Answers to your questions

**So can I say that many different households were paying?**

answered — No—you cannot describe Disney’s reported 180.7 million Disney+ and Hulu subscriptions at fiscal Q2 2025 quarter-end as 180.7 million different paying households. The total is not deduplicated across services: Disney counts subscribers to multi-product offerings separately for each included service. The cited disclosure does not establish the number of distinct paying households. For U.S. multi-product offerings, a subscriber counts as a paid subscriber for each included Disney service. Specifically, a Hulu Live TV + SVOD subscriber counts once for Hulu Live TV + SVOD, once for Disney+, and once for ESPN+. Consequently, that bundle contributes to both the Disney+ and Hulu counts; ESPN+ is separate from the combined Disney+ and Hulu total. These definitions appear on page 16, under “DTC PRODUCT DESCRIPTIONS AND KEY DEFINITIONS,” in Disney’s May 7, 2025 earnings release (saved passage characters [26551:28318)). The release identifies fiscal Q2 2025 as the “second fiscal quarter ended March 29, 2025” on page 1 (saved passage characters [0:6000)). Original source: https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf. [claim:dis-household-count-limitation, claim:dis-bundle-counting-rules, claim:dis-counting-source-period]

**What exactly does the company count?**

answered — Disney defines paid subscribers as subscribers “for which we recognized subscription revenue.” This is the company’s revenue-based subscriber definition, not a count of individual viewers or households. Source: “Paid subscribers,” page 16 of Disney’s May 7, 2025 earnings release. Disney includes subscribers entitled to a service through wholesale arrangements, including arrangements in which the service is available to each subscriber of an existing content-distribution tier. Thus, the count is not restricted to customers buying a standalone subscription directly from Disney. Extra members added to an account through an extra-member add-on are not counted as paid subscribers. Subscribers cease to count as paid subscribers as of their effective cancellation date or as a result of a failed payment method. [claim:dis-paid-subscriber-revenue-definition, claim:dis-wholesale-entitlements, claim:dis-extra-member-exclusion, claim:dis-subscriber-cessation]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_87258ad4804e70335dd6bd5e** (DIS;  to ): manifest.json
  Locator: documents[2]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_c32bb7cef0175f6e8e0729b3** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_2d8c5936a0b1f8623f80eda8** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[9777:11617] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_7a8a6ab350f15d909d44995d** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:1798] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_d37290571b5c2a2fed0998d0** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[7750:8883] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_62b86eb163756c5431c9438b** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[6894:8016] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **span_6f7977dbabd83dc63eab4ad2** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[11617:17617] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_d176ca5b9e7c9bcabcfa359a** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[26551:28318] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_f2729b2526b9baabb8815920** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[15255:16499] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 0; active seconds: 45.08.
Token usage (when returned by provider): {"planner_steps": 2, "total_tokens": 93071, "total_tokens_reported_calls": 4, "prompt_tokens": 89907, "prompt_tokens_reported_calls": 4, "completion_tokens": 3164, "completion_tokens_reported_calls": 4, "cached_input_tokens": 61948, "cached_input_tokens_reported_calls": 4, "cache_write_tokens": 8856, "cache_write_tokens_reported_calls": 4, "cache_write_30m_tokens": 8856, "cache_write_30m_tokens_reported_calls": 4, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 4, "reasoning_tokens": 0, "reasoning_tokens_reported_calls": 4}
