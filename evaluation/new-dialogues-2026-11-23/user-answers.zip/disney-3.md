# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** How many Disney+ and Hulu subscriptions did they have then, and how much had that total changed since the previous quarter?
**Request ID:** new-disney-3
**Model mode:** configured_model
**Scope version:** 7

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-05-07",
  "requirements": [
    {
      "id": "request:episode_cfb5d9e13ca84a9498bd205eb887f073",
      "text": "Report Disney+ and Hulu subscriptions at fiscal Q2 2025 quarter-end, their combined total and its change from fiscal Q1 2025, citing Disney's disclosure and distinguishing subscriptions from unique subscribers."
    }
  ]
}
```

## Findings

### claim:dis-q2-2025-subscriptions — Supported

At March 29, 2025, Disney had 126.0 million Disney+ subscriptions and 54.7 million Hulu subscriptions. The previous-quarter figures, at December 28, 2024, were 124.6 million and 53.6 million, respectively. Source: page 6 subscriber table in Disney’s May 7, 2025 earnings release, saved passage characters [11617:17617).

Evidence: span_6f7977dbabd83dc63eab4ad2
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The page 6 paid-subscriber table, stated in millions, reports total Disney+ of 126.0 and total Hulu of 54.7 at March 29, 2025, versus 124.6 and 53.6 at December 28, 2024. Its heading explicitly identifies a sequential-quarter comparison. The claim correctly uses quarter-end subscription counts rather than the adjacent revenue-per-subscriber metrics.
span_6f7977dbabd83dc63eab4ad2

### claim:dis-q2-2025-combined-subscriptions — Supported

Disney directly reported a combined 180.7 million Disney+ and Hulu subscriptions at fiscal Q2 2025 quarter-end, up 2.5 million from fiscal Q1 2025. This is the issuer-reported total and change, not an independent calculation. Source: page 1 highlights of Disney’s earnings release: https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf.

Evidence: span_c32bb7cef0175f6e8e0729b3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The May 7, 2025 release's page 1 highlights explicitly state “180.7 million Disney+ and Hulu subscriptions, an increase of 2.5 million versus Q1 fiscal 2025.” Its opening identifies fiscal Q2 2025 as ended March 29, 2025. Both the total and change are directly disclosed, so no independent calculation is needed.
span_c32bb7cef0175f6e8e0729b3

### claim:dis-subscriptions-not-unique-people — Supported

The combined figure represents subscriptions, not unique people: Disney’s page 16 definitions say customers with multi-product offerings are counted as paid subscribers for each included service. A customer subscribed to both Disney+ and Hulu can therefore appear in both counts.

Evidence: chunk_d176ca5b9e7c9bcabcfa359a
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The page 16 paid-subscriber definitions state that subscribers to U.S. multi-product offerings count as paid subscribers for each included service, and specifically that Hulu Live TV + SVOD subscribers count for Hulu, Disney+ and ESPN+. This supports the warning that the combined Disney+ and Hulu count is not a deduplicated count of people.
chunk_d176ca5b9e7c9bcabcfa359a

### claim:dis-subscription-fiscal-period — Supported

The release identifies Disney’s fiscal Q2 2025 as the “second fiscal quarter ended March 29, 2025” (page 1, saved passage characters [0:6000)). The page 6 table compares March 29, 2025 with December 28, 2024 on a sequential-quarter basis, and the opening highlights identify the preceding quarter as Q1 fiscal 2025.

Evidence: span_c32bb7cef0175f6e8e0729b3, span_6f7977dbabd83dc63eab4ad2
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release opening expressly names the second fiscal quarter ended March 29, 2025. The subscriber table identifies March 29, 2025 and December 28, 2024 as sequential-quarter endpoints, while the opening subscription highlight names the comparison quarter as Q1 fiscal 2025. Together these passages establish the claimed fiscal-period mapping.
span_c32bb7cef0175f6e8e0729b3 span_6f7977dbabd83dc63eab4ad2

## Answers to your questions

**How many Disney+ and Hulu subscriptions did they have then, and how much had that total changed since the previous quarter?**

answered — Disney directly reported a combined 180.7 million Disney+ and Hulu subscriptions at fiscal Q2 2025 quarter-end, up 2.5 million from fiscal Q1 2025. This is the issuer-reported total and change, not an independent calculation. Source: page 1 highlights of Disney’s earnings release: https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf. At March 29, 2025, Disney had 126.0 million Disney+ subscriptions and 54.7 million Hulu subscriptions. The previous-quarter figures, at December 28, 2024, were 124.6 million and 53.6 million, respectively. Source: page 6 subscriber table in Disney’s May 7, 2025 earnings release, saved passage characters [11617:17617). The combined figure represents subscriptions, not unique people: Disney’s page 16 definitions say customers with multi-product offerings are counted as paid subscribers for each included service. A customer subscribed to both Disney+ and Hulu can therefore appear in both counts. The release identifies Disney’s fiscal Q2 2025 as the “second fiscal quarter ended March 29, 2025” (page 1, saved passage characters [0:6000)). The page 6 table compares March 29, 2025 with December 28, 2024 on a sequential-quarter basis, and the opening highlights identify the preceding quarter as Q1 fiscal 2025. [claim:dis-q2-2025-combined-subscriptions, claim:dis-q2-2025-subscriptions, claim:dis-subscriptions-not-unique-people, claim:dis-subscription-fiscal-period]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_87258ad4804e70335dd6bd5e** (DIS;  to ): manifest.json
  Locator: documents[2]; snapshot SHA-256: b9fd3680656bf4509fe269d54930faa94b41191134d0becd5d0ef8f09f70201c
- **span_c32bb7cef0175f6e8e0729b3** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_2d8c5936a0b1f8623f80eda8** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[9777:11617] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_7a8a6ab350f15d909d44995d** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[0:1798] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_d37290571b5c2a2fed0998d0** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[7750:8883] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_62b86eb163756c5431c9438b** (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[6894:8016] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **span_6f7977dbabd83dc63eab4ad2**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[11617:17617] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_d176ca5b9e7c9bcabcfa359a**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[26551:28318] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf
- **chunk_f2729b2526b9baabb8815920**（本轮留存） (DIS;  to ): [source](<https://thewaltdisneycompany.com/app/uploads/2025/05/q2-fy25-earnings.pdf>)
  Locator: snapshots/DIS.pdf.text.txt:characters[15255:16499] (zero-based Unicode offsets); snapshot SHA-256: f18c015efe01030609d1b4b44700aa2392845236ed47e9b85d4ae6c3dd11fcdf

## Reproducible calculations


## Resource use

Model attempts: 6; tool attempts: 2; active seconds: 49.00.
Token usage (when returned by provider): {"planner_steps": 4, "total_tokens": 120181, "total_tokens_reported_calls": 6, "prompt_tokens": 117584, "prompt_tokens_reported_calls": 6, "completion_tokens": 2597, "completion_tokens_reported_calls": 6, "cached_input_tokens": 66226, "cached_input_tokens_reported_calls": 6, "cache_write_tokens": 21455, "cache_write_tokens_reported_calls": 6, "cache_write_30m_tokens": 21455, "cache_write_30m_tokens_reported_calls": 6, "cache_write_12h_tokens": 0, "cache_write_12h_tokens_reported_calls": 6, "reasoning_tokens": 65, "reasoning_tokens_reported_calls": 6}
