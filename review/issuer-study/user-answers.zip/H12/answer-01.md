# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Compare Accenture's recognized revenue with its new bookings in fiscal Q3 2025. Give the difference using the amounts in the earnings release, and tell me whether I can treat the difference as deferred revenue. Cite the Form 10-Q and the release.
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-06-24T23:59:59-04:00",
  "entities": [
    "Accenture"
  ],
  "metrics": [
    "recognized revenue",
    "new bookings",
    "deferred revenue"
  ],
  "requirements": [
    {
      "id": "R1",
      "text": "Identify Accenture's fiscal Q3 2025 period and compare recognized revenue with new bookings using the earnings release amounts; calculate their difference and specify currency and scale."
    },
    {
      "id": "R2",
      "text": "Explain whether the bookings-minus-revenue difference can be treated as deferred revenue, grounded in the issuer's bookings definition and Form 10-Q revenue recognition and deferred revenue disclosures."
    },
    {
      "id": "R3",
      "text": "Cite both the fiscal Q3 2025 earnings release and Form 10-Q, using sources available by June 24, 2025."
    }
  ]
}
```

## Findings

### claim:period — Supported

Accenture's fiscal Q3 2025 was the quarter ended May 31, 2025. The earnings release states: “third quarter of fiscal 2025 ended May 31, 2025” (release page 1; saved text characters [0:1229]).

Evidence: chunk_aca9ef90e32740867fb73266
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release explicitly identifies fiscal Q3 2025 as the quarter ended May 31, 2025.
chunk_aca9ef90e32740867fb73266

### claim:revenue — Supported

The release's Q3 FY25 Financial Review reports recognized revenue of US$17.73 billion (page 2, Revenues; saved text characters [2034:3607]).

Evidence: chunk_1e7929f99142bd1651be72fc
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Q3 FY25 Financial Review reports total quarterly revenues of US$17.73 billion, distinct from bookings.
chunk_1e7929f99142bd1651be72fc

### claim:bookings — Supported

The same release reports fiscal Q3 2025 new bookings of US$19.70 billion (page 2, New Bookings; saved text characters [2034:3607]).

Evidence: chunk_1e7929f99142bd1651be72fc
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release reports fiscal Q3 2025 new bookings of US$19.70 billion.
chunk_1e7929f99142bd1651be72fc

### claim:difference — Supported

Using the release's rounded amounts, new bookings minus recognized revenue is US$19.70 billion − US$17.73 billion = approximately US$1.97 billion. This is arithmetic on the disclosed figures, not a saved tool-verified calculation.

Evidence: chunk_1e7929f99142bd1651be72fc
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

Independent subtraction of the same-quarter release amounts gives 19.70 − 17.73 = US$1.97 billion. The claim appropriately qualifies the rounded operands and does not claim a saved calculation receipt.
chunk_1e7929f99142bd1651be72fc

### claim:accounting — Supported

No—the difference is neither deferred revenue nor its change. The Form 10-Q's MD&A defines bookings to include new contracts, acquisitions, renewals, extensions and changes to existing contracts. Managed-services bookings typically cover multiple years; many contracts are cancellable, and bookings involve estimates and are not updated for certain subsequent terminations. Consequently, quarterly bookings and quarterly recognized revenue are not matched cohorts: revenue recognized this quarter need not originate in this quarter's bookings. Note 2 separately reports deferred revenues as “Contract liabilities (Deferred revenues)” and discloses quarterly revenue recognized from the opening deferred-revenue balance. These disclosures do not establish a bookings-minus-revenue reconciliation to deferred revenue.

Evidence: chunk_8094d8710afa79ad33ce3ef9, chunk_7ee5892e16c7fcc610de69ed, chunk_f124607eeb73564451d6c2c4
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

MD&A includes acquired contracts, renewals, extensions and changes in bookings, describes multi-year conversion and cancellation limitations, and warns against substituting bookings for revenue analysis. Note 2 separately identifies deferred revenues as contract liabilities and reports US$2.8 billion of quarterly revenue recognized from the opening deferred-revenue balance. These passages support the cohort distinction and explain why the subtraction is not a measure of deferred revenue or its change; no contract-level reconciliation is asserted.
chunk_8094d8710afa79ad33ce3ef9 chunk_7ee5892e16c7fcc610de69ed chunk_f124607eeb73564451d6c2c4

### claim:sources — Supported

Both cited sources were published June 20, 2025, before the June 24, 2025 cutoff: earnings release https://newsroom.accenture.com/content/3qfy25-earnings/accenture-reports-third-quarter-fiscal-2025-results.pdf ; Form 10-Q https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm .

Evidence: chunk_aca9ef90e32740867fb73266, chunk_7ee5892e16c7fcc610de69ed
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

Both source records identify publication on June 20, 2025 and supply the cited release and Form 10-Q URLs, preceding the June 24 cutoff.
chunk_aca9ef90e32740867fb73266 chunk_7ee5892e16c7fcc610de69ed

## Answers to your questions

**Compare Accenture's recognized revenue with its new bookings in fiscal Q3 2025. Give the difference using the amounts in the earnings release, and tell me whether I can treat the difference as deferred revenue. Cite the Form 10-Q and the release.**

answered — Using the release's rounded amounts, new bookings minus recognized revenue is US$19.70 billion − US$17.73 billion = approximately US$1.97 billion. This is arithmetic on the disclosed figures, not a saved tool-verified calculation. Accenture's fiscal Q3 2025 was the quarter ended May 31, 2025. The earnings release states: “third quarter of fiscal 2025 ended May 31, 2025” (release page 1; saved text characters [0:1229]). The release's Q3 FY25 Financial Review reports recognized revenue of US$17.73 billion (page 2, Revenues; saved text characters [2034:3607]). The same release reports fiscal Q3 2025 new bookings of US$19.70 billion (page 2, New Bookings; saved text characters [2034:3607]). No—the difference is neither deferred revenue nor its change. The Form 10-Q's MD&A defines bookings to include new contracts, acquisitions, renewals, extensions and changes to existing contracts. Managed-services bookings typically cover multiple years; many contracts are cancellable, and bookings involve estimates and are not updated for certain subsequent terminations. Consequently, quarterly bookings and quarterly recognized revenue are not matched cohorts: revenue recognized this quarter need not originate in this quarter's bookings. Note 2 separately reports deferred revenues as “Contract liabilities (Deferred revenues)” and discloses quarterly revenue recognized from the opening deferred-revenue balance. These disclosures do not establish a bookings-minus-revenue reconciliation to deferred revenue. Both cited sources were published June 20, 2025, before the June 24, 2025 cutoff: earnings release https://newsroom.accenture.com/content/3qfy25-earnings/accenture-reports-third-quarter-fiscal-2025-results.pdf ; Form 10-Q https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm . [claim:difference, claim:period, claim:revenue, claim:bookings, claim:accounting, claim:sources]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_aca9ef90e32740867fb73266**（本轮留存） (ACN;  to ): [source](<https://newsroom.accenture.com/content/3qfy25-earnings/accenture-reports-third-quarter-fiscal-2025-results.pdf>)
  Locator: snapshots/acnr.pdf.text.txt:characters[0:1229] (zero-based Unicode offsets); snapshot SHA-256: e59ad68e4dc28793ae44b16d291cd0c0293c693e24109d8fe47fb5ec40554765
- **chunk_1e7929f99142bd1651be72fc**（本轮留存） (ACN;  to ): [source](<https://newsroom.accenture.com/content/3qfy25-earnings/accenture-reports-third-quarter-fiscal-2025-results.pdf>)
  Locator: snapshots/acnr.pdf.text.txt:characters[2034:3607] (zero-based Unicode offsets); snapshot SHA-256: e59ad68e4dc28793ae44b16d291cd0c0293c693e24109d8fe47fb5ec40554765
- **chunk_7ee5892e16c7fcc610de69ed**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[85886:87485] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f
- **chunk_d3a534f028071ede89f2ec17**（本轮留存） (ACN;  to ): [source](<https://newsroom.accenture.com/content/3qfy25-earnings/accenture-reports-third-quarter-fiscal-2025-results.pdf>)
  Locator: snapshots/acnr.pdf.text.txt:characters[979:2300] (zero-based Unicode offsets); snapshot SHA-256: e59ad68e4dc28793ae44b16d291cd0c0293c693e24109d8fe47fb5ec40554765
- **chunk_c40c9e684bb7341d30c5832e**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[39124:40858] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f
- **chunk_074dae790b2b5d1d9a7332a9**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[75810:77339] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f
- **chunk_6afc6ff73639076b259ef7cc**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[39076:40858] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f
- **chunk_f124607eeb73564451d6c2c4**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[40554:42326] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f
- **chunk_8094d8710afa79ad33ce3ef9**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[84354:86197] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f
- **chunk_4da7045f5009e42a7538cb0b**（本轮留存） (ACN;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1467373/000146737325000169/acn-20250531.htm>)
  Locator: snapshots/acnq.html.text.txt:characters[37568:39372] (zero-based Unicode offsets); snapshot SHA-256: 38c4848e3d19cfe02090af64c5ca0c0e0e0e8c9299ec8776306d904dca67370f

## Reproducible calculations


## Resource use

Model attempts: 7; tool attempts: 3; active seconds: 246.85.
Token usage (when returned by provider): {"planner_steps": 5, "prompt_tokens": 148695, "prompt_tokens_reported_calls": 7, "completion_tokens": 3632, "completion_tokens_reported_calls": 7, "cached_input_tokens": 23168, "cached_input_tokens_reported_calls": 7, "total_tokens": 152327, "total_tokens_reported_calls": 7}
