# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What was CME Group's average daily contract volume in Q2 2025, how much did it grow year over year, and what were GAAP and adjusted diluted EPS?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 4

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-07-27T23:59:59-04:00",
  "entities": [
    "CME"
  ],
  "requirements": [
    {
      "id": "r1",
      "text": "Report CME Group's Q2 2025 average daily contract volume and its year-over-year percentage growth, supported by the issuer's disclosure available at the cutoff."
    },
    {
      "id": "r2",
      "text": "Report CME Group's Q2 2025 GAAP and adjusted diluted EPS in USD per share, clearly distinguishing the accounting bases."
    }
  ]
}
```

## Findings

### claim:adv — Supported

CME Group reported average daily volume of 30.2 million contracts for fiscal Q2 2025. Its July 23, 2025 release identifies the period as the “second quarter of 2025” and reports “Record average daily volume (ADV) of 30.2 million contracts, up 16% from Q2 2024.” Locator: snapshots/cme.html.text.txt:characters[0:1622].

Evidence: chunk_eec33d2184b15bfc99e8a70e
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The July 23, 2025 issuer release explicitly reports Q2 2025 ADV of 30.2 million contracts before the cutoff. The operating statistics table corroborates this rounded amount with 30,217 thousand contracts for 2Q 2025.
chunk_eec33d2184b15bfc99e8a70e chunk_461faa3ea9cb44e4520d993e

### claim:adv-growth — Supported

CME Group reported Q2 2025 average daily volume growth of 16% versus Q2 2024; this is the issuer's rounded reported growth rate, not a separately calculated rate.

Evidence: chunk_eec33d2184b15bfc99e8a70e
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release explicitly states ADV was up 16% from Q2 2024. The claim correctly identifies this as the issuer's rounded reported rate rather than a separately calculated percentage.
chunk_eec33d2184b15bfc99e8a70e

### claim:gaap-eps — Supported

CME Group's fiscal Q2 2025 GAAP diluted earnings per common share were USD 2.81, as reported in the July 23 release's opening results passage (characters[0:1622]).

Evidence: chunk_eec33d2184b15bfc99e8a70e
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The opening Q2 2025 results passage reports diluted earnings per common share of $2.81 separately from adjusted results. The GAAP-to-non-GAAP reconciliation corroborates the reported diluted EPS and accounting-basis distinction.
chunk_eec33d2184b15bfc99e8a70e chunk_8b7007cc1a25ffa79f02416e

### claim:adjusted-eps — Supported

CME Group's fiscal Q2 2025 adjusted diluted earnings per common share were USD 2.96. This is a non-GAAP measure excluding certain items detailed in the release's reconciliation, distinct from GAAP EPS.

Evidence: chunk_eec33d2184b15bfc99e8a70e
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release reports Q2 2025 adjusted diluted EPS of $2.96 and explicitly says adjusted results exclude items detailed in the non-GAAP reconciliation. The reconciliation's quarterly columns and adjusted diluted EPS row corroborate the amount.
chunk_eec33d2184b15bfc99e8a70e chunk_8b7007cc1a25ffa79f02416e chunk_491c9366e53152b99fb75ad6

## Answers to your questions

**What was CME Group's average daily contract volume in Q2 2025, how much did it grow year over year, and what were GAAP and adjusted diluted EPS?**

answered — CME Group reported average daily volume of 30.2 million contracts for fiscal Q2 2025. Its July 23, 2025 release identifies the period as the “second quarter of 2025” and reports “Record average daily volume (ADV) of 30.2 million contracts, up 16% from Q2 2024.” Locator: snapshots/cme.html.text.txt:characters[0:1622]. CME Group reported Q2 2025 average daily volume growth of 16% versus Q2 2024; this is the issuer's rounded reported growth rate, not a separately calculated rate. CME Group's fiscal Q2 2025 GAAP diluted earnings per common share were USD 2.81, as reported in the July 23 release's opening results passage (characters[0:1622]). CME Group's fiscal Q2 2025 adjusted diluted earnings per common share were USD 2.96. This is a non-GAAP measure excluding certain items detailed in the release's reconciliation, distinct from GAAP EPS. [claim:adv, claim:adv-growth, claim:gaap-eps, claim:adjusted-eps]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_4f47fab82131580d09621fc7**（本轮留存） (CME;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1156375/000115637525000176/exhibit9916302025.htm>)
  Locator: snapshots/cme.html.text.txt:characters[1131:3113] (zero-based Unicode offsets); snapshot SHA-256: b9c121e4085aea5c52738a5ac031b4d28f00854a47c5f366969096e0d6156214
- **chunk_eec33d2184b15bfc99e8a70e**（本轮留存） (CME;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1156375/000115637525000176/exhibit9916302025.htm>)
  Locator: snapshots/cme.html.text.txt:characters[0:1622] (zero-based Unicode offsets); snapshot SHA-256: b9c121e4085aea5c52738a5ac031b4d28f00854a47c5f366969096e0d6156214
- **chunk_491c9366e53152b99fb75ad6**（本轮留存） (CME;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1156375/000115637525000176/exhibit9916302025.htm>)
  Locator: snapshots/cme.html.text.txt:characters[16075:17117] (zero-based Unicode offsets); snapshot SHA-256: b9c121e4085aea5c52738a5ac031b4d28f00854a47c5f366969096e0d6156214
- **chunk_8b7007cc1a25ffa79f02416e**（本轮留存） (CME;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1156375/000115637525000176/exhibit9916302025.htm>)
  Locator: snapshots/cme.html.text.txt:characters[14530:16325] (zero-based Unicode offsets); snapshot SHA-256: b9c121e4085aea5c52738a5ac031b4d28f00854a47c5f366969096e0d6156214
- **chunk_461faa3ea9cb44e4520d993e**（本轮留存） (CME;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1156375/000115637525000176/exhibit9916302025.htm>)
  Locator: snapshots/cme.html.text.txt:characters[16825:18329] (zero-based Unicode offsets); snapshot SHA-256: b9c121e4085aea5c52738a5ac031b4d28f00854a47c5f366969096e0d6156214

## Reproducible calculations


## Resource use

Model attempts: 5; tool attempts: 1; active seconds: 176.95.
Token usage (when returned by provider): {"planner_steps": 3, "prompt_tokens": 83330, "prompt_tokens_reported_calls": 5, "completion_tokens": 2102, "completion_tokens_reported_calls": 5, "cached_input_tokens": 13824, "cached_input_tokens_reported_calls": 5, "total_tokens": 85432, "total_tokens_reported_calls": 5}
