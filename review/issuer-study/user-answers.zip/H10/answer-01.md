# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What was Mastercard's reported and currency-neutral net revenue growth in Q2 2025?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-08-04T23:59:59-04:00",
  "entities": [
    "Mastercard"
  ],
  "metrics": [
    "reported net revenue growth",
    "currency-neutral net revenue growth"
  ],
  "requirements": [
    {
      "id": "R1",
      "text": "Identify Mastercard's reported and currency-neutral year-over-year net revenue growth in Q2 2025, citing the issuer's disclosure available by the cutoff."
    }
  ]
}
```

## Findings

### claim:reported_growth — Supported

Mastercard’s net revenue grew 17% year over year on a reported GAAP basis in fiscal Q2 2025. Its July 31, 2025 earnings release labels the comparison “Q2 2025 Q2 2024” in the Second Quarter Operating Results table (snapshots/ma.html.text.txt:characters[821:2553]). Source: https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm.

Evidence: chunk_92d7196d7ce5b35d23addea0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Second Quarter Operating Results table compares Q2 2025 with Q2 2024 and reports total net revenue growth of 17% under Reported GAAP. The issuer disclosure's July 31, 2025 publication date precedes the cutoff, and its source URL and locator match the claim.
chunk_92d7196d7ce5b35d23addea0

### claim:currency_neutral_growth — Supported

Mastercard’s net revenue grew 16% year over year on a currency-neutral basis in fiscal Q2 2025. The same release states: “Net revenue increased 17%, or 16% on a currency-neutral basis” (snapshots/ma.html.text.txt:characters[2305:3985]).

Evidence: chunk_a279f878a49a4e34b5c1fefc, chunk_92d7196d7ce5b35d23addea0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The passage explicitly identifies second-quarter 2025 results versus the year-ago period and states net revenue increased 16% on a currency-neutral basis. The quarterly table independently confirms 16% for total net revenue, rather than a segment or year-to-date metric.
chunk_a279f878a49a4e34b5c1fefc chunk_92d7196d7ce5b35d23addea0

## Answers to your questions

**What was Mastercard's reported and currency-neutral net revenue growth in Q2 2025?**

answered — Mastercard’s net revenue grew 17% year over year on a reported GAAP basis in fiscal Q2 2025. Its July 31, 2025 earnings release labels the comparison “Q2 2025 Q2 2024” in the Second Quarter Operating Results table (snapshots/ma.html.text.txt:characters[821:2553]). Source: https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm. Mastercard’s net revenue grew 16% year over year on a currency-neutral basis in fiscal Q2 2025. The same release states: “Net revenue increased 17%, or 16% on a currency-neutral basis” (snapshots/ma.html.text.txt:characters[2305:3985]). [claim:reported_growth, claim:currency_neutral_growth]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_a279f878a49a4e34b5c1fefc**（本轮留存） (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[2305:3985] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_92d7196d7ce5b35d23addea0**（本轮留存） (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[821:2553] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_b0c1cccb7e20d29d54d8d589**（本轮留存） (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[6738:8451] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_0db0bf912449f0a8fd58fed2**（本轮留存） (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[8105:9919] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_4b79278dbc1833eae4841f1c**（本轮留存） (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[3649:5426] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5

## Reproducible calculations


## Resource use

Model attempts: 5; tool attempts: 1; active seconds: 150.66.
Token usage (when returned by provider): {"planner_steps": 3, "prompt_tokens": 79552, "prompt_tokens_reported_calls": 5, "completion_tokens": 1564, "completion_tokens_reported_calls": 5, "cached_input_tokens": 17280, "cached_input_tokens_reported_calls": 5, "total_tokens": 81116, "total_tokens_reported_calls": 5}
