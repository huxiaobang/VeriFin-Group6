# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Does the reported cross-border volume growth establish how much of total net revenue growth came from cross-border activity?
**Request ID:** quarter-message-2
**Model mode:** codex_subscription
**Scope version:** 4

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-08-04T23:59:59-04:00",
  "entities": [
    "Mastercard"
  ],
  "metrics": [
    "reported net revenue growth",
    "currency-neutral net revenue growth"
  ],
  "requirements": [
    {
      "id": "request:episode_9c88783eb3bc43699c1d00f48886ed0d",
      "text": "Does the reported cross-border volume growth establish how much of total net revenue growth came from cross-border activity?"
    }
  ]
}
```

## Findings

Research skills: reconcile-fee-bases

### claim:cross_border_volume_driver — Supported

For fiscal Q2 2025 versus Q2 2024, Mastercard disclosed 15% cross-border volume growth on a local-currency basis. Management identified this as one of the primary drivers of payment-network net revenue growth, alongside gross dollar volume and switched transactions—not as a measured contribution to consolidated net revenue growth. The release labels the period “Q2 2025 Key Business Drivers (YoY growth)” (snapshots/ma.html.text.txt:characters[2305:3985]).

Evidence: chunk_a279f878a49a4e34b5c1fefc
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Q2 2025 year-over-year passage reports cross-border volume growth of 15% on a local-currency basis and lists it alongside gross dollar volume and switched transactions as primary drivers of payment-network net revenue growth. This supports management attribution within payment network, not a quantified consolidated revenue contribution. The July 31, 2025 publication precedes the cutoff.
chunk_a279f878a49a4e34b5c1fefc

### claim:cross_border_contribution_not_established — Supported

No. The supplied disclosure does not establish how many percentage points—or what share—of Mastercard’s total net revenue growth of 17% reported or 16% currency-neutral came from cross-border activity. Payment volume is not recognized net revenue: the passage does not isolate cross-border net revenue, its effective fee rate, or its incremental net revenue contribution. Other payment-network drivers, customer rebates and incentives, and value-added services and solutions also affect total net revenue. Management’s driver attribution is therefore not an arithmetic revenue bridge; dividing the volume and revenue growth rates would not establish a contribution share.

Evidence: chunk_a279f878a49a4e34b5c1fefc
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The quarterly disclosure and table establish total net revenue growth of 17% reported and 16% currency-neutral. The driver passage separately reports volume growth, other payment-network drivers, customer rebates and incentives, and value-added services growth, but provides no isolated cross-border net revenue, effective fee rate or incremental revenue allocation. The draft correctly limits its conclusion to the supplied disclosure and explains why dividing distinct growth rates cannot establish a contribution share.
chunk_a279f878a49a4e34b5c1fefc chunk_92d7196d7ce5b35d23addea0

## Answers to your questions

**Does the reported cross-border volume growth establish how much of total net revenue growth came from cross-border activity?**

answered — No. The supplied disclosure does not establish how many percentage points—or what share—of Mastercard’s total net revenue growth of 17% reported or 16% currency-neutral came from cross-border activity. Payment volume is not recognized net revenue: the passage does not isolate cross-border net revenue, its effective fee rate, or its incremental net revenue contribution. Other payment-network drivers, customer rebates and incentives, and value-added services and solutions also affect total net revenue. Management’s driver attribution is therefore not an arithmetic revenue bridge; dividing the volume and revenue growth rates would not establish a contribution share. For fiscal Q2 2025 versus Q2 2024, Mastercard disclosed 15% cross-border volume growth on a local-currency basis. Management identified this as one of the primary drivers of payment-network net revenue growth, alongside gross dollar volume and switched transactions—not as a measured contribution to consolidated net revenue growth. The release labels the period “Q2 2025 Key Business Drivers (YoY growth)” (snapshots/ma.html.text.txt:characters[2305:3985]). [claim:cross_border_contribution_not_established, claim:cross_border_volume_driver]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_a279f878a49a4e34b5c1fefc** (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[2305:3985] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_92d7196d7ce5b35d23addea0** (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[821:2553] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_b0c1cccb7e20d29d54d8d589** (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[6738:8451] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_0db0bf912449f0a8fd58fed2** (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[8105:9919] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5
- **chunk_4b79278dbc1833eae4841f1c** (MA;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1141391/000114139125000170/ma06302025-exx991xearnings.htm>)
  Locator: snapshots/ma.html.text.txt:characters[3649:5426] (zero-based Unicode offsets); snapshot SHA-256: 8e40373a35c375f64a6029550d75b3941413029afd47ccac0fa4c8fed04f01c5

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 0; active seconds: 143.18.
Token usage (when returned by provider): {"planner_steps": 2, "prompt_tokens": 66891, "prompt_tokens_reported_calls": 4, "completion_tokens": 1697, "completion_tokens_reported_calls": 4, "cached_input_tokens": 13824, "cached_input_tokens_reported_calls": 4, "total_tokens": 68588, "total_tokens_reported_calls": 4}
