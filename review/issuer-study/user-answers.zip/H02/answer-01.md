# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What were Union Pacific's reported and adjusted operating ratios in Q2 2025, and how many percentage points apart were they?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-07-28T23:59:59-04:00",
  "entities": [
    "Union Pacific"
  ],
  "metrics": [
    "reported operating ratio",
    "adjusted operating ratio",
    "operating ratio percentage-point difference"
  ],
  "requirements": [
    {
      "id": "R1",
      "text": "Establish Union Pacific's reported and adjusted operating ratios for Q2 2025 from its original disclosure available by the cutoff."
    },
    {
      "id": "R2",
      "text": "Calculate and report the percentage-point difference between the Q2 2025 reported and adjusted operating ratios, identifying which was higher."
    }
  ]
}
```

## Findings

### claim:reported_or — Supported

Union Pacific's reported GAAP operating ratio for fiscal Q2 2025, the three months ended June 30, 2025, was 59.0%. The July 24, 2025 release identifies the quarter as “Union Pacific Reports Second Quarter 2025 Results” (snapshots/unp.html.text.txt:characters[0:1800]); the quarterly reconciliation is on page 7, characters[19923:21663]. Source: https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm.

Evidence: chunk_801e603ff7ca1b0fc27d1e6d, chunk_db3c90a5c2bc6bee1dff0da0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The July 24, 2025 release identifies second-quarter results, before the cutoff. The consolidated reconciliation for the three months ended June 30, 2025 reports a GAAP operating ratio of 59.0%; its heading and locator also support the cited page and period.
chunk_801e603ff7ca1b0fc27d1e6d chunk_db3c90a5c2bc6bee1dff0da0

### claim:adjusted_or — Supported

For the same fiscal Q2 2025 period, Union Pacific's adjusted non-GAAP operating ratio was 58.1%, as shown in the three-month reconciliation—not the six-month table.

Evidence: chunk_db3c90a5c2bc6bee1dff0da0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The operating-ratio row in the three-month 2025 reconciliation gives 58.1% under adjusted results (non-GAAP). This is the quarterly figure, not the six-month figure.
chunk_db3c90a5c2bc6bee1dff0da0

### claim:or_gap — Supported

The reported operating ratio was 0.9 percentage points higher than the adjusted ratio. This gap is disclosed directly as the downward crew-staffing-agreement adjustment in the quarterly reconciliation; it is not backed by a saved calculation. Percentage-cell extraction returned no candidates in two attempts.

Evidence: chunk_db3c90a5c2bc6bee1dff0da0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The quarterly row shows reported 59.0%, a downward crew-staffing adjustment of 0.9 percentage points, and adjusted 58.1%. Subtracting the displayed ratios independently confirms that reported was 0.9 percentage points higher. No saved calculation is supplied, and the two recorded extraction attempts returned no candidates, as the claim acknowledges.
chunk_db3c90a5c2bc6bee1dff0da0

## Answers to your questions

**What were Union Pacific's reported and adjusted operating ratios in Q2 2025, and how many percentage points apart were they?**

answered — The reported operating ratio was 0.9 percentage points higher than the adjusted ratio. This gap is disclosed directly as the downward crew-staffing-agreement adjustment in the quarterly reconciliation; it is not backed by a saved calculation. Percentage-cell extraction returned no candidates in two attempts. Union Pacific's reported GAAP operating ratio for fiscal Q2 2025, the three months ended June 30, 2025, was 59.0%. The July 24, 2025 release identifies the quarter as “Union Pacific Reports Second Quarter 2025 Results” (snapshots/unp.html.text.txt:characters[0:1800]); the quarterly reconciliation is on page 7, characters[19923:21663]. Source: https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm. For the same fiscal Q2 2025 period, Union Pacific's adjusted non-GAAP operating ratio was 58.1%, as shown in the three-month reconciliation—not the six-month table. [claim:or_gap, claim:reported_or, claim:adjusted_or]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_51386464e4a913543da751d7**（本轮留存） (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[22140:23905] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_db3c90a5c2bc6bee1dff0da0**（本轮留存） (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[19923:21663] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_801e603ff7ca1b0fc27d1e6d**（本轮留存） (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[0:1800] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_92c26ae6d4d97fece976c019**（本轮留存） (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[1496:2653] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_1108fcd8da71e1de78252d00**（本轮留存） (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[23657:25086] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a

## Reproducible calculations


## Resource use

Model attempts: 7; tool attempts: 3; active seconds: 253.91.
Token usage (when returned by provider): {"planner_steps": 5, "prompt_tokens": 113079, "prompt_tokens_reported_calls": 7, "completion_tokens": 2387, "completion_tokens_reported_calls": 7, "cached_input_tokens": 23168, "cached_input_tokens_reported_calls": 7, "total_tokens": 115466, "total_tokens_reported_calls": 7}
