# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** Which item accounts for the difference? Did the deferred tax benefit also change the operating ratio?
**Request ID:** quarter-message-2
**Model mode:** codex_subscription
**Scope version:** 5

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-07-28T23:59:59-04:00",
  "entities": [
    "Union Pacific"
  ],
  "metrics": [
    "reported operating ratio",
    "adjusted operating ratio",
    "operating ratio percentage-point difference"
  ],
  "requirements": [
    {
      "id": "request:episode_0487e9833d074f9b86941c4ba749c1d2",
      "text": "Identify the item accounting for Union Pacific's Q2 2025 reported-versus-adjusted operating-ratio difference, and establish whether the deferred tax benefit also affected the operating ratio."
    }
  ]
}
```

## Findings

### claim:crew_staffing_or_adjustment — Supported

Union Pacific's USD 55 million crew staffing agreement accounts for the entire disclosed 0.9-percentage-point operating-ratio adjustment in fiscal Q2 2025: excluding it reduced operating expenses and moved the reported GAAP operating ratio of 59.0% to the adjusted non-GAAP ratio of 58.1%. The original quarterly reconciliation is on page 7, snapshots/unp.html.text.txt:characters[19923:21663]. The release identifies the quarter as “Union Pacific Reports Second Quarter 2025 Results” at characters[0:1800]. Source: https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm.

Evidence: chunk_db3c90a5c2bc6bee1dff0da0, chunk_801e603ff7ca1b0fc27d1e6d
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The consolidated reconciliation on page 7 for the three months ended June 30, 2025 shows the crew staffing adjustment reducing operating expenses by USD 55 million and operating ratio by 0.9 percentage points, from 59.0% to 58.1%. The deferred-tax column has no operating-ratio adjustment. The release identifies Q2 2025 and was published July 24, before the cutoff; its source URL and supplied offsets support the cited locator.
chunk_db3c90a5c2bc6bee1dff0da0 chunk_801e603ff7ca1b0fc27d1e6d

### claim:deferred_tax_no_or_effect — Supported

No—the USD 115 million deferred tax benefit affected income tax expense and net income, not operating ratio. In the same fiscal Q2 2025 reconciliation, the deferred-tax-adjustment column shows dashes for operating expenses, operating income and operating ratio, while removing the benefit reduces net income by USD 115 million. Thus, it was not part of the operating-ratio difference.

Evidence: chunk_db3c90a5c2bc6bee1dff0da0
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release identifies a USD 115 million deferred tax benefit. In the Q2 2025 reconciliation, its adjustment column shows dashes for operating expenses, operating income and operating ratio, and a USD 115 million reduction to net income when the benefit is removed. This supports the distinction between its tax and net-income effects and its absence from the operating-ratio adjustment.
chunk_db3c90a5c2bc6bee1dff0da0 chunk_801e603ff7ca1b0fc27d1e6d

## Answers to your questions

**Which item accounts for the difference?**

answered — Union Pacific's USD 55 million crew staffing agreement accounts for the entire disclosed 0.9-percentage-point operating-ratio adjustment in fiscal Q2 2025: excluding it reduced operating expenses and moved the reported GAAP operating ratio of 59.0% to the adjusted non-GAAP ratio of 58.1%. [claim:crew_staffing_or_adjustment]

**Did the deferred tax benefit also change the operating ratio?**

answered — No—the USD 115 million deferred tax benefit affected income tax expense and net income, not operating ratio. [claim:deferred_tax_no_or_effect]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_51386464e4a913543da751d7** (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[22140:23905] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_db3c90a5c2bc6bee1dff0da0** (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[19923:21663] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_801e603ff7ca1b0fc27d1e6d** (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[0:1800] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_92c26ae6d4d97fece976c019** (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[1496:2653] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a
- **chunk_1108fcd8da71e1de78252d00** (UNP;  to ): [source](<https://www.sec.gov/Archives/edgar/data/100885/000010088525000250/a2025-07x248xkex991earning.htm>)
  Locator: snapshots/unp.html.text.txt:characters[23657:25086] (zero-based Unicode offsets); snapshot SHA-256: b1654a86ff7098a1d7a650a38b5d5c00f83f3fa7e2f37af48e15e36d959aee9a

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 0; active seconds: 162.13.
Token usage (when returned by provider): {"planner_steps": 2, "prompt_tokens": 67819, "prompt_tokens_reported_calls": 4, "completion_tokens": 1731, "completion_tokens_reported_calls": 4, "cached_input_tokens": 13824, "cached_input_tokens_reported_calls": 4, "total_tokens": 69550, "total_tokens_reported_calls": 4}
