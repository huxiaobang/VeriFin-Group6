# VeriFin research report

**Status:** partial
**Stop reason:** unresolved_items
**Request:** What were Intuitive Surgical's da Vinci system placements in Q2 2025 and Q2 2024?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-07-26T23:59:59-04:00",
  "entities": [
    "Intuitive Surgical"
  ],
  "metrics": [
    "da Vinci system placements"
  ],
  "requirements": [
    {
      "id": "R1",
      "text": "Report Intuitive Surgical's da Vinci system placements in Q2 2025 and Q2 2024, supported by issuer disclosures available at the cutoff."
    }
  ]
}
```

## Findings

### claim:placements_2025q2 — Insufficient Evidence

Intuitive Surgical placed 395 da Vinci surgical systems in fiscal Q2 2025. Its July 22, 2025 earnings release states: “The Company placed 395 da Vinci surgical systems” and identifies the period as “the second quarter of 2025.” Source: release passage at snapshots/isrg.html.text.txt:characters[2908:4696].

Evidence: chunk_ed86d23de48cd19d6cf6b4c6, chunk_264ef99f8a12587969710c34
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The issuer release explicitly reports 395 da Vinci surgical system placements in the second quarter of 2025. Its heading identifies the quarter ended June 30, 2025 and publication on July 22, 2025, before the cutoff. The original passages resolve the rule-flagged reporting dimensions without a substantive mismatch.
chunk_ed86d23de48cd19d6cf6b4c6 chunk_264ef99f8a12587969710c34

### claim:placements_2024q2 — Insufficient Evidence

Intuitive Surgical placed 341 da Vinci surgical systems in fiscal Q2 2024. The same July 22, 2025 release provides the prior-year comparison: “compared with 341 in the second quarter of 2024.” Source: Q2 Highlights at snapshots/isrg.html.text.txt:characters[0:1800]. Both reported figures were disclosed before the July 26, 2025 cutoff.

Evidence: chunk_264ef99f8a12587969710c34
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Q2 Highlights explicitly compare da Vinci surgical system placements with 341 in the second quarter of 2024. The July 22, 2025 issuer release establishes that both figures were disclosed before the cutoff. The comparative period and system-count unit are explicit despite the automated mismatch finding.
chunk_264ef99f8a12587969710c34

## Answers to your questions

**What were Intuitive Surgical's da Vinci system placements in Q2 2025 and Q2 2024?**

gap — 对应主张未通过核验：Every cited result conflicts with at least one stated source dimension.

## Unanswered items and issues

- R1: Report Intuitive Surgical's da Vinci system placements in Q2 2025 and Q2 2024, supported by issuer disclosures available at the cutoff.
- claim:placements_2025q2: context_mismatch. Every cited result conflicts with at least one stated source dimension. Suggested action: Check the company, metric, dates, unit and reporting basis against the source.
- claim:placements_2024q2: context_mismatch. Every cited result conflicts with at least one stated source dimension. Suggested action: Check the company, metric, dates, unit and reporting basis against the source.

## Evidence and source locations

- **chunk_5c46e26740807567904fb8ba**（本轮留存） (ISRG;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1035267/000103526725000183/q225ex-991earningsrelease.htm>)
  Locator: snapshots/isrg.html.text.txt:characters[1437:3204] (zero-based Unicode offsets); snapshot SHA-256: 13f29301af752fee929e1c1bfc8b28b487a4a4507a5c58ae85be6eb032cb320a
- **chunk_264ef99f8a12587969710c34**（本轮留存） (ISRG;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1035267/000103526725000183/q225ex-991earningsrelease.htm>)
  Locator: snapshots/isrg.html.text.txt:characters[0:1800] (zero-based Unicode offsets); snapshot SHA-256: 13f29301af752fee929e1c1bfc8b28b487a4a4507a5c58ae85be6eb032cb320a
- **chunk_ed86d23de48cd19d6cf6b4c6**（本轮留存） (ISRG;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1035267/000103526725000183/q225ex-991earningsrelease.htm>)
  Locator: snapshots/isrg.html.text.txt:characters[2908:4696] (zero-based Unicode offsets); snapshot SHA-256: 13f29301af752fee929e1c1bfc8b28b487a4a4507a5c58ae85be6eb032cb320a
- **chunk_bf08c2d06c852e3c8a1048ee**（本轮留存） (ISRG;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1035267/000103526725000183/q225ex-991earningsrelease.htm>)
  Locator: snapshots/isrg.html.text.txt:characters[4327:6100] (zero-based Unicode offsets); snapshot SHA-256: 13f29301af752fee929e1c1bfc8b28b487a4a4507a5c58ae85be6eb032cb320a
- **chunk_b6e2264e5cae988f1ab08cdd**（本轮留存） (ISRG;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1035267/000103526725000183/q225ex-991earningsrelease.htm>)
  Locator: snapshots/isrg.html.text.txt:characters[7251:9023] (zero-based Unicode offsets); snapshot SHA-256: 13f29301af752fee929e1c1bfc8b28b487a4a4507a5c58ae85be6eb032cb320a

## Reproducible calculations


## Resource use

Model attempts: 5; tool attempts: 1; active seconds: 176.76.
Token usage (when returned by provider): {"planner_steps": 3, "prompt_tokens": 80580, "prompt_tokens_reported_calls": 5, "completion_tokens": 1557, "completion_tokens_reported_calls": 5, "cached_input_tokens": 13824, "cached_input_tokens_reported_calls": 5, "total_tokens": 82137, "total_tokens_reported_calls": 5}
