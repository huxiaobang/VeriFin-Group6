# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What were UPS's reported and adjusted consolidated operating margins for Q2 2025?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 4

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-08-02T23:59:59-04:00",
  "entities": [
    "UPS"
  ],
  "requirements": [
    {
      "id": "R1",
      "text": "Identify UPS's reported consolidated operating margin for Q2 2025 from its original disclosure available by the cutoff."
    },
    {
      "id": "R2",
      "text": "Identify UPS's adjusted consolidated operating margin for Q2 2025, distinguishing its non-GAAP basis from the reported margin."
    }
  ]
}
```

## Findings

### claim:reported_margin — Supported

UPS's reported GAAP consolidated operating margin for fiscal Q2 2025 was 8.6%. Its July 29, 2025 release, titled “UPS Releases 2Q 2025 Earnings,” states “Consolidated Operating Margin of 8.6%.” Source: https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings; locator: snapshots/ups.html.text.txt:characters[0:1775].

Evidence: chunk_967ab3687410e91eff5d1f3c
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

UPS's July 29, 2025 original Q2 earnings release explicitly reports consolidated operating margin of 8.6%, separately from the non-GAAP adjusted margin. The accounting-policy passage identifies reported results as GAAP. Publication precedes the cutoff.
chunk_967ab3687410e91eff5d1f3c chunk_7ea238ed676aaa29d7c26ecb

### claim:adjusted_margin — Supported

UPS's non-GAAP adjusted consolidated operating margin for fiscal Q2 2025 was 8.8%, distinct from its reported GAAP margin. The same release states “Non-GAAP Adjusted * Consolidated Operating Margin of 8.8%” (snapshots/ups.html.text.txt:characters[0:1775]). UPS cautions that adjusted measures supplement, rather than replace, GAAP results.

Evidence: chunk_967ab3687410e91eff5d1f3c, chunk_7ea238ed676aaa29d7c26ecb
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Q2 2025 release explicitly labels the 8.8% consolidated operating margin non-GAAP adjusted. The separate non-GAAP passage supports the caution that adjusted measures supplement rather than replace GAAP results; it is explanatory context, not the source of the margin value.
chunk_967ab3687410e91eff5d1f3c chunk_7ea238ed676aaa29d7c26ecb

## Answers to your questions

**What were UPS's reported and adjusted consolidated operating margins for Q2 2025?**

answered — UPS's reported GAAP consolidated operating margin for fiscal Q2 2025 was 8.6%. Its July 29, 2025 release, titled “UPS Releases 2Q 2025 Earnings,” states “Consolidated Operating Margin of 8.6%.” Source: https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings; locator: snapshots/ups.html.text.txt:characters[0:1775]. UPS's non-GAAP adjusted consolidated operating margin for fiscal Q2 2025 was 8.8%, distinct from its reported GAAP margin. The same release states “Non-GAAP Adjusted * Consolidated Operating Margin of 8.8%” (snapshots/ups.html.text.txt:characters[0:1775]). UPS cautions that adjusted measures supplement, rather than replace, GAAP results. [claim:reported_margin, claim:adjusted_margin]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_967ab3687410e91eff5d1f3c**（本轮留存） (UPS;  to ): [source](<https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings>)
  Locator: snapshots/ups.html.text.txt:characters[0:1775] (zero-based Unicode offsets); snapshot SHA-256: 08116e70c47eb67890718507476a91f59e2e57c61d11c94ae705817e2aded2e3
- **chunk_cb24ca141e5ce6c0aa1ea226**（本轮留存） (UPS;  to ): [source](<https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings>)
  Locator: snapshots/ups.html.text.txt:characters[1439:3130] (zero-based Unicode offsets); snapshot SHA-256: 08116e70c47eb67890718507476a91f59e2e57c61d11c94ae705817e2aded2e3
- **chunk_7ea238ed676aaa29d7c26ecb**（本轮留存） (UPS;  to ): [source](<https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings>)
  Locator: snapshots/ups.html.text.txt:characters[11315:13266] (zero-based Unicode offsets); snapshot SHA-256: 08116e70c47eb67890718507476a91f59e2e57c61d11c94ae705817e2aded2e3
- **chunk_1480ea4df4885b59bf885fc4**（本轮留存） (UPS;  to ): [source](<https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings>)
  Locator: snapshots/ups.html.text.txt:characters[2757:4612] (zero-based Unicode offsets); snapshot SHA-256: 08116e70c47eb67890718507476a91f59e2e57c61d11c94ae705817e2aded2e3
- **chunk_644df9df3a214db0b525b6a7**（本轮留存） (UPS;  to ): [source](<https://investors.ups.com/news-events/press-releases/detail/2146/ups-releases-2q-2025-earnings>)
  Locator: snapshots/ups.html.text.txt:characters[23618:25034] (zero-based Unicode offsets); snapshot SHA-256: 08116e70c47eb67890718507476a91f59e2e57c61d11c94ae705817e2aded2e3

## Reproducible calculations


## Resource use

Model attempts: 5; tool attempts: 1; active seconds: 155.99.
Token usage (when returned by provider): {"planner_steps": 3, "prompt_tokens": 80385, "prompt_tokens_reported_calls": 5, "completion_tokens": 1521, "completion_tokens_reported_calls": 5, "cached_input_tokens": 17280, "cached_input_tokens_reported_calls": 5, "total_tokens": 81906, "total_tokens_reported_calls": 5}
