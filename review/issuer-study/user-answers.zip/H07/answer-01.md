# VeriFin research report

**Status:** partial
**Stop reason:** unresolved_items
**Request:** What were Stryker's reported and adjusted operating margins in Q2 2025, and how large was the spread in percentage points?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-08-04T23:59:59-04:00",
  "requirements": [
    {
      "id": "R1",
      "text": "Identify Stryker's reported operating margin for Q2 2025 from its original disclosure available by the cutoff."
    },
    {
      "id": "R2",
      "text": "Identify Stryker's adjusted operating margin for the same quarter and distinguish its non-GAAP basis."
    },
    {
      "id": "R3",
      "text": "Calculate the adjusted-minus-reported operating-margin spread in percentage points using saved numeric operands and cite the sources and calculation."
    }
  ]
}
```

## Findings

### claim:reported_margin — Supported

Stryker's reported GAAP operating margin for fiscal Q2 2025 was 18.5%. Its July 31, 2025 release states “STRYKER REPORTS SECOND QUARTER 2025 OPERATING RESULTS” and “Reported operating income margin of 18.5%” (snapshots/syk.html.text.txt:characters[0:1784]). The GAAP-to-non-GAAP reconciliation confirms the reported margin. Source: https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm.

Evidence: chunk_12170cf1c63301a4c919c8a3, chunk_c0e1f0bce51169a0542eddff
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The July 31, 2025 release explicitly identifies second-quarter 2025 results and an 18.5% reported operating income margin. The reconciliation's Three Months 2025 reported operating-income percentage confirms 18.5% on a consolidated GAAP basis, before the cutoff.
chunk_12170cf1c63301a4c919c8a3 chunk_c0e1f0bce51169a0542eddff

### claim:adjusted_margin — Supported

For the same quarter, Stryker's adjusted operating margin was 25.7%, a non-GAAP measure excluding specified items rather than the reported GAAP margin. The release's Earnings Analysis states this rate, and its reconciliation shows the adjusted percentage of net sales across the saved passage boundary at character 22247.

Evidence: chunk_0515501fa5ceffb61d97aa56, chunk_069730776d19f772ad9fbc4c, chunk_c0e1f0bce51169a0542eddff, span_da20cf88da2228ba7926e504
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

Earnings Analysis states a 25.7% adjusted operating income margin after specified exclusions; footnote (1) identifies it as non-GAAP. The Three Months 2025 reconciliation's adjusted percentage row continues across character 22247, where 25.7% occupies the operating-income column.
chunk_0515501fa5ceffb61d97aa56 chunk_069730776d19f772ad9fbc4c chunk_c0e1f0bce51169a0542eddff span_da20cf88da2228ba7926e504

### claim:spread_limitation — Supported

The displayed rates imply an approximate adjusted-minus-reported spread of 7.2 percentage points. No saved calculation receipt is available: both percentage-cell searches returned no numeric operands, and the document read returned text only. Thus, this is a comparison of rounded disclosed rates, not a completed saved-operand calculation.

Evidence: chunk_12170cf1c63301a4c919c8a3
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

Subtracting the disclosed rounded margins gives 25.7% minus 18.5% = approximately 7.2 percentage points. The supplied tool history confirms two searches returned no candidate percentage cells and the read was text-only; the calculations list is empty. The claim appropriately distinguishes this arithmetic from a saved-operand calculation.
chunk_12170cf1c63301a4c919c8a3

## Answers to your questions

**What were Stryker's reported and adjusted operating margins in Q2 2025, and how large was the spread in percentage points?**

answered — The displayed rates imply an approximate adjusted-minus-reported spread of 7.2 percentage points. No saved calculation receipt is available: both percentage-cell searches returned no numeric operands, and the document read returned text only. Thus, this is a comparison of rounded disclosed rates, not a completed saved-operand calculation. Stryker's reported GAAP operating margin for fiscal Q2 2025 was 18.5%. Its July 31, 2025 release states “STRYKER REPORTS SECOND QUARTER 2025 OPERATING RESULTS” and “Reported operating income margin of 18.5%” (snapshots/syk.html.text.txt:characters[0:1784]). The GAAP-to-non-GAAP reconciliation confirms the reported margin. Source: https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm. For the same quarter, Stryker's adjusted operating margin was 25.7%, a non-GAAP measure excluding specified items rather than the reported GAAP margin. The release's Earnings Analysis states this rate, and its reconciliation shows the adjusted percentage of net sales across the saved passage boundary at character 22247. [claim:spread_limitation, claim:reported_margin, claim:adjusted_margin]

## Unanswered items and issues

- R3: Calculate the adjusted-minus-reported operating-margin spread in percentage points using saved numeric operands and cite the sources and calculation.
- R3: missing_provenance. The approximate 7.2-percentage-point spread is supported by the disclosed rates, but no saved numeric operands or calculation record are supplied. The draft correctly discloses this limitation. Suggested action: Retain the approximate displayed-rate comparison and its limitation. To complete R3's additional provenance requirement, obtain saved matching operands and a saved subtraction calculation.

## Evidence and source locations

- **metadata_20870275baebef794adf3095**（本轮留存） (SYK;  to ): manifest.json
  Locator: documents[6]; snapshot SHA-256: 177cf1830a57ad8bf1819fd47af377504c20aac43c95cc13bd4eeb69bcd4d6f2
- **chunk_12170cf1c63301a4c919c8a3**（本轮留存） (SYK;  to ): [source](<https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm>)
  Locator: snapshots/syk.html.text.txt:characters[0:1784] (zero-based Unicode offsets); snapshot SHA-256: 861183067a487ae600403d56555868156832e3ed544f1ea39a69073b9b2eec6d
- **chunk_0515501fa5ceffb61d97aa56**（本轮留存） (SYK;  to ): [source](<https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm>)
  Locator: snapshots/syk.html.text.txt:characters[1434:3215] (zero-based Unicode offsets); snapshot SHA-256: 861183067a487ae600403d56555868156832e3ed544f1ea39a69073b9b2eec6d
- **chunk_069730776d19f772ad9fbc4c**（本轮留存） (SYK;  to ): [source](<https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm>)
  Locator: snapshots/syk.html.text.txt:characters[2838:4520] (zero-based Unicode offsets); snapshot SHA-256: 861183067a487ae600403d56555868156832e3ed544f1ea39a69073b9b2eec6d
- **chunk_c39edbb93cd988b563bf7d43**（本轮留存） (SYK;  to ): [source](<https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm>)
  Locator: snapshots/syk.html.text.txt:characters[15948:17737] (zero-based Unicode offsets); snapshot SHA-256: 861183067a487ae600403d56555868156832e3ed544f1ea39a69073b9b2eec6d
- **chunk_c0e1f0bce51169a0542eddff**（本轮留存） (SYK;  to ): [source](<https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm>)
  Locator: snapshots/syk.html.text.txt:characters[20386:22247] (zero-based Unicode offsets); snapshot SHA-256: 861183067a487ae600403d56555868156832e3ed544f1ea39a69073b9b2eec6d
- **span_da20cf88da2228ba7926e504**（本轮留存） (SYK;  to ): [source](<https://www.sec.gov/Archives/edgar/data/310764/000031076425000103/sykex991earningsq22025.htm>)
  Locator: snapshots/syk.html.text.txt:characters[22247:26247] (zero-based Unicode offsets); snapshot SHA-256: 861183067a487ae600403d56555868156832e3ed544f1ea39a69073b9b2eec6d

## Reproducible calculations


## Resource use

Model attempts: 9; tool attempts: 5; active seconds: 334.81.
Token usage (when returned by provider): {"planner_steps": 7, "prompt_tokens": 156018, "prompt_tokens_reported_calls": 9, "completion_tokens": 3291, "completion_tokens_reported_calls": 9, "cached_input_tokens": 26624, "cached_input_tokens_reported_calls": 9, "total_tokens": 159309, "total_tokens_reported_calls": 9}
