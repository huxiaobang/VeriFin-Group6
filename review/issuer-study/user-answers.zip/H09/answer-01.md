# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What were S&P Global's actual GAAP and adjusted diluted EPS in Q2 2025?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-08-04T23:59:59-04:00",
  "requirements": [
    {
      "id": "r1",
      "text": "Report S&P Global's actual GAAP diluted EPS and adjusted diluted EPS for Q2 2025, including currency per share, supported by its original disclosure available by the cutoff."
    }
  ]
}
```

## Findings

### claim:gaap_eps — Supported

S&P Global reported actual GAAP diluted EPS of US$3.50 per share for fiscal Q2 2025. Its July 31, 2025 earnings release labels the table “Second Quarter 2025 Diluted Earnings Per Share” and reports “GAAP Diluted EPS $3.50”. Source: page 2, snapshots/spgi.html.text.txt:characters[2875:4186]; https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm.

Evidence: chunk_94cf72546de8dfc2ce47b8a7
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The original release's page 2 EPS table reports GAAP diluted EPS of $3.50 in the 2Q '25 column, separately from $3.23 for 2Q '24. The release identifies S&P Global and is dated July 31, 2025, before the cutoff. This is reported company-wide quarterly EPS, not full-year guidance.
chunk_94cf72546de8dfc2ce47b8a7 chunk_5722bbe4488efd2525ef3110

### claim:adjusted_eps — Supported

S&P Global reported actual adjusted diluted EPS (non-GAAP) of US$4.43 per share for fiscal Q2 2025. The same July 31, 2025 release’s page 2 table reports “Adjusted Diluted EPS $4.43” under “2Q '25” (snapshots/spgi.html.text.txt:characters[2875:4186]).

Evidence: chunk_94cf72546de8dfc2ce47b8a7
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The original release's page 2 EPS table reports adjusted diluted EPS of $4.43 in the 2Q '25 column, separately from $4.04 for 2Q '24. The passage explicitly identifies adjusted financials as non-GAAP. The July 31, 2025 release predates the cutoff and reports actual quarterly results.
chunk_94cf72546de8dfc2ce47b8a7 chunk_5722bbe4488efd2525ef3110

## Answers to your questions

**What were S&P Global's actual GAAP and adjusted diluted EPS in Q2 2025?**

answered — S&P Global reported actual GAAP diluted EPS of US$3.50 per share for fiscal Q2 2025. Its July 31, 2025 earnings release labels the table “Second Quarter 2025 Diluted Earnings Per Share” and reports “GAAP Diluted EPS $3.50”. Source: page 2, snapshots/spgi.html.text.txt:characters[2875:4186]; https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm. S&P Global reported actual adjusted diluted EPS (non-GAAP) of US$4.43 per share for fiscal Q2 2025. The same July 31, 2025 release’s page 2 table reports “Adjusted Diluted EPS $4.43” under “2Q '25” (snapshots/spgi.html.text.txt:characters[2875:4186]). [claim:gaap_eps, claim:adjusted_eps]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **chunk_94cf72546de8dfc2ce47b8a7**（本轮留存） (SPGI;  to ): [source](<https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm>)
  Locator: snapshots/spgi.html.text.txt:characters[2875:4186] (zero-based Unicode offsets); snapshot SHA-256: 9a6ba656edacf7c72aabd4a6effe831b4e0575f469a1cdf03fb4697a89268f48
- **chunk_5722bbe4488efd2525ef3110**（本轮留存） (SPGI;  to ): [source](<https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm>)
  Locator: snapshots/spgi.html.text.txt:characters[0:1786] (zero-based Unicode offsets); snapshot SHA-256: 9a6ba656edacf7c72aabd4a6effe831b4e0575f469a1cdf03fb4697a89268f48
- **chunk_698ec44a82c9a26596cd36c7**（本轮留存） (SPGI;  to ): [source](<https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm>)
  Locator: snapshots/spgi.html.text.txt:characters[5227:7174] (zero-based Unicode offsets); snapshot SHA-256: 9a6ba656edacf7c72aabd4a6effe831b4e0575f469a1cdf03fb4697a89268f48
- **chunk_75a931989f87c9a4613a7bf6**（本轮留存） (SPGI;  to ): [source](<https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm>)
  Locator: snapshots/spgi.html.text.txt:characters[1444:3199] (zero-based Unicode offsets); snapshot SHA-256: 9a6ba656edacf7c72aabd4a6effe831b4e0575f469a1cdf03fb4697a89268f48
- **chunk_bd1f7db7a63c27172e9ab105**（本轮留存） (SPGI;  to ): [source](<https://www.sec.gov/Archives/edgar/data/64040/000006404025000143/spgi2q2025-earningsrelease.htm>)
  Locator: snapshots/spgi.html.text.txt:characters[3865:5623] (zero-based Unicode offsets); snapshot SHA-256: 9a6ba656edacf7c72aabd4a6effe831b4e0575f469a1cdf03fb4697a89268f48

## Reproducible calculations


## Resource use

Model attempts: 5; tool attempts: 1; active seconds: 165.82.
Token usage (when returned by provider): {"planner_steps": 3, "prompt_tokens": 79034, "prompt_tokens_reported_calls": 5, "completion_tokens": 1432, "completion_tokens_reported_calls": 5, "cached_input_tokens": 13824, "cached_input_tokens_reported_calls": 5, "total_tokens": 80466, "total_tokens_reported_calls": 5}
