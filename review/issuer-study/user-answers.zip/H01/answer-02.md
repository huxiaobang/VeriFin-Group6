# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What about Diagnostics? How did its reported and organic growth compare, and what changes if COVID-19 testing sales are excluded?
**Request ID:** quarter-message-2
**Model mode:** codex_subscription
**Scope version:** 5

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-07-21T23:59:59-04:00",
  "requirements": [
    {
      "id": "request:episode_86ba9a89e4754e59aab02fac0e6285b8",
      "text": "What about Diagnostics? How did its reported and organic growth compare, and what changes if COVID-19 testing sales are excluded?"
    }
  ],
  "entities": [
    "ABT"
  ],
  "period_start": "2025-04-01",
  "period_end": "2025-06-30",
  "metrics": [
    "Diagnostics reported sales growth",
    "Diagnostics organic sales growth",
    "Diagnostics organic sales growth excluding COVID-19 testing sales"
  ]
}
```

## Findings

Research skills: reconcile-comparable-growth, attribute-portfolio-growth

### claim:diagnostics-q2-2025-reported — Supported

Abbott's worldwide Diagnostics sales declined 1.0% on a reported basis in fiscal second-quarter 2025 versus second-quarter 2024. The July 17, 2025 release identifies the period as the "second quarter ended June 30, 2025" (page 1); the rate appears on page 2, "Second Quarter 2025 Results (2Q25)," Diagnostics column, "Total reported" row.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The release dated July 17, 2025 identifies the quarter ended June 30, 2025. Page 2's Diagnostics column shows total reported growth of (1.0)% versus 2Q24, supporting the worldwide scope, period and decline.
span_73902495c5bda84b7aeb7173

### claim:diagnostics-q2-2025-organic — Supported

Diagnostics organic sales declined 1.4% in fiscal second-quarter 2025 versus second-quarter 2024, a steeper decline than on the reported basis. This organic rate includes COVID-19 testing sales.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The quarterly Diagnostics Organic row shows (1.4)%, a steeper decline than reported growth of (1.0)%. The separate COVID-excluded row establishes that the ordinary organic rate includes COVID-19 testing sales.
span_73902495c5bda84b7aeb7173

### claim:diagnostics-q2-2025-fx — Supported

Abbott's table discloses a positive foreign-exchange impact of 0.4 percentage points for Diagnostics, reconciling the organic decline to the smaller reported decline at the table's displayed precision.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The 2Q25 Diagnostics foreign-exchange impact row shows positive 0.4. At displayed precision, −1.4% organic growth plus 0.4 percentage points equals −1.0% reported growth.
span_73902495c5bda84b7aeb7173

### claim:diagnostics-q2-2025-excluding-covid — Supported

Excluding COVID-19 testing sales, Diagnostics organic sales grew 0.8% in fiscal second-quarter 2025 versus second-quarter 2024. The exclusion changes organic performance from contraction to growth; it does not make reported growth positive.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The 2Q25 Diagnostics Organic (excluding COVID-19 tests) row shows 0.8%, compared with ordinary organic growth of (1.4)%. This changes the organic comparison to growth; the disclosed reported rate remains −1.0%. The claim distinguishes these bases rather than establishing a separate COVID-excluded reported rate.
span_73902495c5bda84b7aeb7173

### claim:diagnostics-q2-2025-covid-impact — Supported

The same table discloses a negative COVID-19 testing sales impact of 2.2 percentage points on Diagnostics organic growth, rather than a negative 2.2% growth rate for COVID-19 testing sales themselves.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The quarterly Diagnostics Impact of COVID-19 testing sales row shows (2.2), reconciling 0.8% COVID-excluded organic growth to −1.4% including COVID-19 tests. It is a percentage-point growth impact, not the testing business's own growth rate.
span_73902495c5bda84b7aeb7173

### claim:diagnostics-organic-definition — Supported

Abbott defines organic growth as excluding foreign-exchange effects and the discontinuation of ZonePerfect in Nutrition; the latter is not a Diagnostics adjustment. The cited definition does not specify an acquisition adjustment, so organic should not be relabeled as acquisition-excluded growth.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

The business overview defines organic growth as excluding foreign exchange and the ZonePerfect discontinuation specifically in Nutrition. It does not specify an acquisition adjustment, supporting the stated limitation and distinguishing the Nutrition adjustment from Diagnostics.
span_73902495c5bda84b7aeb7173

## Answers to your questions

**What about Diagnostics?**

answered — Abbott's worldwide Diagnostics sales declined 1.0% on a reported basis in fiscal second-quarter 2025 versus second-quarter 2024. The July 17, 2025 release identifies the period as the "second quarter ended June 30, 2025" (page 1); the rate appears on page 2, "Second Quarter 2025 Results (2Q25)," Diagnostics column, "Total reported" row. Diagnostics organic sales declined 1.4% in fiscal second-quarter 2025 versus second-quarter 2024, a steeper decline than on the reported basis. This organic rate includes COVID-19 testing sales. Abbott's table discloses a positive foreign-exchange impact of 0.4 percentage points for Diagnostics, reconciling the organic decline to the smaller reported decline at the table's displayed precision. Excluding COVID-19 testing sales, Diagnostics organic sales grew 0.8% in fiscal second-quarter 2025 versus second-quarter 2024. The exclusion changes organic performance from contraction to growth; it does not make reported growth positive. The same table discloses a negative COVID-19 testing sales impact of 2.2 percentage points on Diagnostics organic growth, rather than a negative 2.2% growth rate for COVID-19 testing sales themselves. Abbott defines organic growth as excluding foreign-exchange effects and the discontinuation of ZonePerfect in Nutrition; the latter is not a Diagnostics adjustment. The cited definition does not specify an acquisition adjustment, so organic should not be relabeled as acquisition-excluded growth. [claim:diagnostics-q2-2025-reported, claim:diagnostics-q2-2025-organic, claim:diagnostics-q2-2025-fx, claim:diagnostics-q2-2025-excluding-covid, claim:diagnostics-q2-2025-covid-impact, claim:diagnostics-organic-definition]

**How did its reported and organic growth compare, and what changes if COVID-19 testing sales are excluded?**

answered — Excluding COVID-19 testing sales, Diagnostics organic sales grew 0.8% in fiscal second-quarter 2025 versus second-quarter 2024. The exclusion changes organic performance from contraction to growth; it does not make reported growth positive. [claim:diagnostics-q2-2025-excluding-covid]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_3405c5b60ba064794da2927c** (ABT;  to ): manifest.json
  Locator: documents[0]; snapshot SHA-256: 177cf1830a57ad8bf1819fd47af377504c20aac43c95cc13bd4eeb69bcd4d6f2
- **span_73902495c5bda84b7aeb7173** (ABT;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1800/000162828025035135/abt-2025q2xexhibitx991.htm>)
  Locator: snapshots/abt.html.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: 0675ed3605efe397ffe128fbef9632148c33dd9778dba7b90a0955d9aedcf0b9

## Reproducible calculations


## Resource use

Model attempts: 4; tool attempts: 0; active seconds: 186.41.
Token usage (when returned by provider): {"planner_steps": 2, "prompt_tokens": 70741, "prompt_tokens_reported_calls": 4, "completion_tokens": 3492, "completion_tokens_reported_calls": 4, "cached_input_tokens": 12800, "cached_input_tokens_reported_calls": 4, "total_tokens": 74233, "total_tokens_reported_calls": 4}
