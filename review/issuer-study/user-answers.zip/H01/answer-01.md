# VeriFin research report

**Status:** complete
**Stop reason:** completed
**Request:** What were Abbott's second-quarter 2025 worldwide sales and year-over-year growth on reported and organic bases?
**Request ID:** quarter-message-1
**Model mode:** codex_subscription
**Scope version:** 3

Model verification is an assessment against the available evidence, not an independent guarantee.

## Scope

```json
{
  "cutoff": "2025-07-21T23:59:59-04:00",
  "requirements": [
    {
      "id": "R1",
      "text": "Report Abbott's second-quarter 2025 worldwide sales, stating currency and scale, from an original disclosure available by the cutoff."
    },
    {
      "id": "R2",
      "text": "Report Abbott's second-quarter 2025 year-over-year worldwide sales growth on reported and organic bases, identifying the issuer's organic-growth definition."
    }
  ]
}
```

## Findings

### claim:abt-q2-2025-sales — Supported

Abbott's fiscal second-quarter 2025 worldwide sales were US$11,142 million. Its July 17, 2025 release identifies the period as the "second quarter ended June 30, 2025" (page 1); page 2, "Second Quarter 2025 Results (2Q25)," reports Total Company sales in the "Total reported" row. Source: https://www.sec.gov/Archives/edgar/data/1800/000162828025035135/abt-2025q2xexhibitx991.htm.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The July 17, 2025 original release predates the cutoff and identifies the quarter ended June 30, 2025. Its page 2 quarterly table reports Total Company total reported sales of 11,142 in dollars in millions; the surrounding methodology identifies U.S. dollars.
span_73902495c5bda84b7aeb7173

### claim:abt-q2-2025-reported-growth — Supported

Worldwide sales increased 7.4% year over year on a reported basis in second-quarter 2025 versus second-quarter 2024.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The Second Quarter 2025 table's % Change vs. 2Q24 section shows 7.4 for Total Company in the Total reported row, confirming the stated worldwide year-over-year reported growth rate.
span_73902495c5bda84b7aeb7173

### claim:abt-q2-2025-organic-growth — Supported

Worldwide sales increased 6.9% year over year on an organic basis in second-quarter 2025 versus second-quarter 2024.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The same quarterly table shows 6.9 for Total Company in the Organic row under % Change vs. 2Q24, confirming the stated period, scope and growth basis.
span_73902495c5bda84b7aeb7173

### claim:abt-organic-definition — Supported

Abbott defines organic sales growth as excluding foreign-exchange effects and the impact of discontinuing the ZonePerfect product line in its Nutrition business. The 6.9% organic rate includes COVID-19 testing sales; the separately disclosed organic rate excluding COVID-19 testing sales was 7.5% for second-quarter 2025 versus second-quarter 2024.

Evidence: span_73902495c5bda84b7aeb7173
Calculations: 

核验方式为原文审读，数字与期间、指标的对应关系需结合引文判断。

The business overview explicitly defines organic growth as excluding foreign exchange and the ZonePerfect discontinuation. The quarterly table distinguishes Organic of 6.9% from Organic (excluding COVID-19 tests) of 7.5%, supporting the inclusion distinction and comparison period.
span_73902495c5bda84b7aeb7173

## Answers to your questions

**What were Abbott's second-quarter 2025 worldwide sales and year-over-year growth on reported and organic bases?**

answered — Abbott's fiscal second-quarter 2025 worldwide sales were US$11,142 million. Its July 17, 2025 release identifies the period as the "second quarter ended June 30, 2025" (page 1); page 2, "Second Quarter 2025 Results (2Q25)," reports Total Company sales in the "Total reported" row. Source: https://www.sec.gov/Archives/edgar/data/1800/000162828025035135/abt-2025q2xexhibitx991.htm. Worldwide sales increased 7.4% year over year on a reported basis in second-quarter 2025 versus second-quarter 2024. Worldwide sales increased 6.9% year over year on an organic basis in second-quarter 2025 versus second-quarter 2024. Abbott defines organic sales growth as excluding foreign-exchange effects and the impact of discontinuing the ZonePerfect product line in its Nutrition business. The 6.9% organic rate includes COVID-19 testing sales; the separately disclosed organic rate excluding COVID-19 testing sales was 7.5% for second-quarter 2025 versus second-quarter 2024. [claim:abt-q2-2025-sales, claim:abt-q2-2025-reported-growth, claim:abt-q2-2025-organic-growth, claim:abt-organic-definition]

## Unanswered items and issues

None identified.

## Evidence and source locations

- **metadata_3405c5b60ba064794da2927c**（本轮留存） (ABT;  to ): manifest.json
  Locator: documents[0]; snapshot SHA-256: 177cf1830a57ad8bf1819fd47af377504c20aac43c95cc13bd4eeb69bcd4d6f2
- **span_73902495c5bda84b7aeb7173**（本轮留存） (ABT;  to ): [source](<https://www.sec.gov/Archives/edgar/data/1800/000162828025035135/abt-2025q2xexhibitx991.htm>)
  Locator: snapshots/abt.html.text.txt:characters[0:6000] (zero-based Unicode offsets); snapshot SHA-256: 0675ed3605efe397ffe128fbef9632148c33dd9778dba7b90a0955d9aedcf0b9

## Reproducible calculations


## Resource use

Model attempts: 6; tool attempts: 2; active seconds: 224.94.
Token usage (when returned by provider): {"planner_steps": 4, "prompt_tokens": 85397, "prompt_tokens_reported_calls": 6, "completion_tokens": 2340, "completion_tokens_reported_calls": 6, "cached_input_tokens": 16256, "cached_input_tokens_reported_calls": 6, "total_tokens": 87737, "total_tokens_reported_calls": 6}
