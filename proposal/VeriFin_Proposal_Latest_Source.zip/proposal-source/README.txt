VeriFin Group 6 proposal, prepared for course submission, 9 October 2026.
Compile VeriFin_Proposal_Latest_EN.tex twice with pdflatex. The original NeurIPS 2026 style is unchanged. The .tex source suppresses the default Preprint footer while retaining named authors.
All four names, student IDs and HKU emails are included. No abstract. The approved architecture is embedded as TikZ.
Latest revision clarifies Structured Critic feedback and its generic-review baseline, limits attribution to the complete scheme, and numbers experiments E1 verification, E2 planning, E3 retrieval.
The submission PDF is Group_6_VeriFin_Proposal.pdf (five pages). It has not been uploaded or submitted by the assistant.
